"""Official-data proximity checks, not government acceptance decisions."""
from functools import lru_cache
import json
import math
from pathlib import Path

from pyproj import Transformer
from shapely import make_valid,transform,STRtree
from shapely.geometry import Point,shape
from shapely.ops import unary_union

class BikewayIndex:
    def __init__(self,directory,buffer_m=20):
        self.directory=Path(directory)
        self.buffer_m=float(buffer_m)
        if not math.isfinite(self.buffer_m) or not 1<=self.buffer_m<=100:
            raise ValueError('BIKEWAY_BUFFER_METERS must be between 1 and 100 metres.')
        self.available=False
        self.collection={'type':'FeatureCollection','features':[]}
        self.boundary_collection={'type':'FeatureCollection','features':[]}
        self.metadata={}
        try:
            self.collection=json.loads((self.directory/'taipei-bikeways.geojson').read_text())
            self.boundary_collection=json.loads((self.directory/'taipei-boundary.geojson').read_text())
            self.metadata=self.collection['metadata']
            self.project=Transformer.from_crs(4326,3826,always_xy=True)
            self.boundary=make_valid(unary_union([transform(shape(f['geometry']),self.project.transform,interleaved=False) for f in self.boundary_collection['features']]))
            self.lines=[transform(shape(f['geometry']),self.project.transform,interleaved=False) for f in self.collection['features']]
            if not self.lines or self.boundary.is_empty:raise ValueError('Empty official GIS layer')
            self.tree=STRtree(self.lines)
            self.available=True
        except (OSError,ValueError,KeyError,TypeError):
            self.metadata={'error':'官方圖資尚未載入，暫時無法比對。'}

    @lru_cache(maxsize=10000)
    def match(self,lat,lng,accuracy=None):
        result={'status':'unavailable','inside_taipei':None,'within_buffer':False,'distance_m':None,
                'buffer_m':self.buffer_m,'nearest_route':None,'position_accuracy_m':accuracy,
                'priority_candidate':False,'government_priority_confirmed':False,
                'dataset_version':self.metadata.get('dataset_version'),'retrieved_on':self.metadata.get('retrieved_on')}
        if not self.available:return result
        # Avoid projecting distant global coordinates into the local Taiwan CRS.
        if not (24<=lat<=26 and 120<=lng<=123):
            return {**result,'status':'outside_taipei','inside_taipei':False}
        x,y=self.project.transform(lng,lat)
        if not math.isfinite(x+y):return {**result,'status':'outside_taipei','inside_taipei':False}
        point=Point(x,y)
        inside=self.boundary.covers(point)
        nearest=int(self.tree.nearest(point))
        distance=float(point.distance(self.lines[nearest]))
        props=self.collection['features'][nearest]['properties']
        route={k:props.get(k) for k in ('route_id','name','kind','maintainer','publisher','source_url')}
        near=distance<=self.buffer_m+1e-6
        boundary_distance=float(point.distance(self.boundary.boundary))
        uncertainty=float(accuracy or 0)
        if uncertainty>50 or (uncertainty>0 and (abs(distance-self.buffer_m)<=uncertainty or boundary_distance<=uncertainty)):
            status='needs_review'
        elif not inside:
            status='outside_taipei'
        elif boundary_distance<3:
            status='needs_review'
        elif near:
            status='matched'
        else:
            status='unmatched'
        return {**result,'status':status,'inside_taipei':bool(inside),'within_buffer':near,
                'distance_m':round(distance,1),'nearest_route':route,'priority_candidate':status=='matched'}

@lru_cache(maxsize=4)
def load_index(directory,buffer_m=20):
    return BikewayIndex(directory,buffer_m)
