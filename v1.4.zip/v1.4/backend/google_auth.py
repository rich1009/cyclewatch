"""Google OIDC and LINE LIFF authentication. Provider tokens are never persisted."""
import hmac
import os
import secrets
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit
from uuid import uuid4

import httpx
from authlib.integrations.starlette_client import OAuth
from fastapi import HTTPException, Request
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, ConfigDict, Field
from starlette.middleware.sessions import SessionMiddleware

class LiffChallenge(BaseModel):
    model_config = ConfigDict(extra='forbid')
    link: bool = False

class LiffCredential(BaseModel):
    model_config = ConfigDict(extra='forbid')
    idToken: str = Field(min_length=100,max_length=12000)
    challenge: str = Field(min_length=20,max_length=200,pattern=r'^[A-Za-z0-9_-]+$')

async def verify_line_token(id_token, channel_id):
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.post('https://api.line.me/oauth2/v2.1/verify',
                                         data={'id_token':id_token,'client_id':channel_id})
        if response.status_code != 200:
            raise ValueError('Rejected token')
        info = response.json()
        if not (info.get('iss')=='https://access.line.me' and str(info.get('aud'))==channel_id
                and float(info.get('exp',0))>time.time()
                and isinstance(info.get('sub'),str) and 0<len(info['sub'])<=255):
            raise ValueError('Invalid claims')
        return info
    except (httpx.HTTPError,ValueError,TypeError,AttributeError):
        raise HTTPException(401,'LINE 驗證失敗或憑證已過期，請重新登入。')

def configure_google(api, database, connect, enabled):
    # Keep the former entry-point name for upgrade compatibility.
    base = os.getenv('PUBLIC_BASE_URL','').rstrip('/')
    mode = os.getenv('AUTH_MODE','receipt')
    providers = [] if not enabled else (['google'] if mode=='google' else ['line'] if mode=='line' else ['google','line'])
    liff_id = os.getenv('LIFF_ID','') if 'line' in providers else ''
    api.state.auth_providers = providers
    api.state.liff_id = liff_id

    @api.get('/api/auth/config')
    def config():
        return {'providers':providers,'liffId':liff_id}

    if not enabled:
        return lambda request:None
    secret = os.getenv('SESSION_SECRET','')
    parts = urlsplit(base)
    if len(secret)<32:
        raise RuntimeError('SESSION_SECRET must contain at least 32 random characters.')
    if (parts.scheme not in ('http','https') or not parts.netloc or parts.username or parts.password
            or parts.path or parts.query or parts.fragment
            or (parts.scheme=='http' and parts.hostname not in ('localhost','127.0.0.1'))):
        raise RuntimeError('PUBLIC_BASE_URL must be an HTTPS origin, or a localhost HTTP origin for local testing.')
    client_id,client_secret = os.getenv('GOOGLE_CLIENT_ID',''),os.getenv('GOOGLE_CLIENT_SECRET','')
    if 'google' in providers and not (client_id and client_secret):
        raise RuntimeError('Google login requires GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.')
    line_channel = os.getenv('LINE_CHANNEL_ID','')
    if 'line' in providers and not (line_channel and liff_id):
        raise RuntimeError('LINE LIFF login requires LINE_CHANNEL_ID and LIFF_ID.')
    if liff_id and parts.scheme!='https':
        raise RuntimeError('LIFF requires a publicly accessible HTTPS PUBLIC_BASE_URL.')
    try:
        session_days=int(os.getenv('SESSION_DAYS','7'))
        if not 1<=session_days<=90:raise ValueError()
    except ValueError:
        raise RuntimeError('SESSION_DAYS must be between 1 and 90.')
    api.add_middleware(SessionMiddleware,secret_key=secret,session_cookie='cyclewatch_session',
                       max_age=86400*session_days,same_site='lax',https_only=parts.scheme=='https')
    oauth=OAuth()
    if 'google' in providers:
        oauth.register(name='google',client_id=client_id,client_secret=client_secret,
                       server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
                       client_kwargs={'scope':'openid email profile','code_challenge_method':'S256','timeout':15})
    api.state.google_oauth=oauth

    def current_user(request):
        uid=request.session.get('uid')
        if not uid:return None
        with connect(database) as conn:
            row=conn.execute('SELECT id,email,name FROM users WHERE id=?',(uid,)).fetchone()
            if not row:return None
            user=dict(row)
            user['providers']=[r['provider'] for r in conn.execute('SELECT provider FROM auth_identities WHERE user_id=? ORDER BY provider',(uid,))]
        return user

    def resolve_identity(provider,info,link_uid=None):
        subject=info['sub']
        email=info.get('email','') if provider=='google' else ''
        name=str(info.get('name') or email or 'LINE 使用者')[:200]
        now=datetime.now(timezone.utc).isoformat()
        with connect(database) as conn:
            conn.execute('BEGIN IMMEDIATE')
            identity=conn.execute('SELECT user_id FROM auth_identities WHERE provider=? AND subject=?',(provider,subject)).fetchone()
            if link_uid:
                if identity and identity['user_id']!=link_uid:
                    raise HTTPException(409,'此登入帳號已屬於另一個使用者，無法自動合併。')
                other=conn.execute('SELECT subject FROM auth_identities WHERE user_id=? AND provider=?',(link_uid,provider)).fetchone()
                if other and other['subject']!=subject:
                    raise HTTPException(409,'目前使用者已綁定另一個同類型帳號，不能直接替換。')
                if not conn.execute('SELECT 1 FROM users WHERE id=?',(link_uid,)).fetchone():
                    raise HTTPException(401,'原登入已失效。')
                uid=link_uid
            elif identity:
                uid=identity['user_id']
                conn.execute('UPDATE users SET name=?,email=CASE WHEN ?!=\'\' THEN ? ELSE email END WHERE id=?',(name,email,email,uid))
            else:
                uid='account:'+uuid4().hex
                conn.execute('INSERT INTO users (id,email,name,createdAt) VALUES (?,?,?,?)',(uid,email,name,now))
            conn.execute('INSERT OR IGNORE INTO auth_identities (provider,subject,user_id,createdAt) VALUES (?,?,?,?)',(provider,subject,uid,now))
        return uid

    if 'google' in providers:
        @api.post('/api/auth/google/link')
        def prepare_google_link(request:Request):
            user=current_user(request)
            if not user:raise HTTPException(401,'請先登入，再綁定另一個帳號。')
            request.session['link_intent']={'uid':user['id'],'provider':'google','exp':time.time()+600}
            return {'url':base+'/api/auth/google/login?link=1'}

        @api.get('/api/auth/google/login')
        async def login(request:Request):
            if 'line/' in request.headers.get('user-agent','').lower():
                raise HTTPException(400,'Google 登入需使用外部瀏覽器，請從 LINE 選單以 Safari 或 Chrome 開啟。')
            if str(request.base_url).rstrip('/')!=base:
                return RedirectResponse(base+'/api/auth/google/login',status_code=302)
            kwargs={'prompt':'select_account'}
            if request.query_params.get('link')=='1':
                intent=request.session.get('link_intent',{})
                if not (intent.get('uid')==request.session.get('uid') and intent.get('provider')=='google' and intent.get('exp',0)>time.time()):
                    raise HTTPException(400,'綁定請求已失效，請從「我的回報」重新開始。')
                state=secrets.token_urlsafe(32)
                intent['state']=state
                request.session['link_intent']=intent
                kwargs['state']=state
            else:
                request.session.pop('link_intent',None)
            return await oauth.google.authorize_redirect(request,base+'/api/auth/google/callback',**kwargs)

        @api.get('/api/auth/google/callback')
        async def callback(request:Request):
            try:
                token=await oauth.google.authorize_access_token(request)
                info=token.get('userinfo',{})
                subject,email=info.get('sub'),info.get('email')
                if not (isinstance(subject,str) and 0<len(subject)<=255 and isinstance(email,str)
                        and 0<len(email)<=320 and info.get('email_verified') is True):raise ValueError('Invalid profile')
                intent=request.session.pop('link_intent',{})
                linking=bool(intent)
                if linking and not (intent.get('state')==request.query_params.get('state')
                                    and intent.get('uid')==request.session.get('uid') and intent.get('exp',0)>time.time()):
                    raise ValueError('Expired or mismatched link intent')
                uid=resolve_identity('google',info,intent['uid'] if linking else None)
                request.session.clear();request.session['uid']=uid
                return RedirectResponse(base+'/?login=success',status_code=303)
            except HTTPException as exc:
                request.session.pop('link_intent',None)
                return RedirectResponse(base+'/?login=conflict' if exc.status_code==409 else base+'/?login=failed',status_code=303)
            except Exception:
                request.session.clear()
                return RedirectResponse(base+'/?login=failed',status_code=303)

    if 'line' in providers:
        @api.post('/api/auth/liff/challenge')
        def challenge(request:Request,body:LiffChallenge):
            user=current_user(request)
            if body.link and not user:raise HTTPException(401,'請先登入，再綁定 LINE。')
            nonce=secrets.token_urlsafe(32)
            request.session['liff_challenge']={'nonce':nonce,'exp':time.time()+180,'uid':user['id'] if body.link else None}
            return {'challenge':nonce}

        @api.post('/api/auth/liff')
        async def liff_login(request:Request,body:LiffCredential):
            intent=request.session.pop('liff_challenge',{})
            if not intent or intent.get('exp',0)<=time.time() or not hmac.compare_digest(intent.get('nonce',''),body.challenge):
                raise HTTPException(400,'LINE 登入請求已失效，請重新開始。')
            target=intent.get('uid')
            if target and target!=request.session.get('uid'):
                raise HTTPException(401,'原帳號登入已失效。')
            info=await verify_line_token(body.idToken,line_channel)
            uid=resolve_identity('line',info,target)
            request.session.clear();request.session['uid']=uid
            return {'authenticated':True,'linked':bool(target)}

    @api.post('/api/auth/logout')
    def logout(request:Request):
        request.session.clear()
        return {'logged_out':True}
    return current_user
