"""CycleWatch self-hosted API and static frontend. Python 3.11+."""
from __future__ import annotations
import base64
import binascii
from contextlib import asynccontextmanager
from datetime import datetime, timezone
import hmac
import hashlib
import secrets
from io import BytesIO
import json
import logging
import os
from pathlib import Path
import sqlite3
from typing import Literal
from uuid import UUID, uuid4
import warnings

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from dotenv import load_dotenv
from .google_auth import configure_google
from .bikeways import load_index

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / '.env', override=False)
MAX_BODY = 6 * 1024 * 1024
MAX_PHOTO = 4 * 1024 * 1024
Image.MAX_IMAGE_PIXELS = 25_000_000
log = logging.getLogger('cyclewatch')

class RedactAccessQuery(logging.Filter):
    """OAuth/LIFF redirects may contain credentials in URL query parameters."""
    def filter(self, record):
        args=record.args
        if isinstance(args,tuple) and len(args)>=3 and isinstance(args[2],str) and '?' in args[2]:
            values=list(args)
            values[2]=values[2].split('?',1)[0]+'?[redacted]'
            record.args=tuple(values)
        return True

logging.getLogger('uvicorn.access').addFilter(RedactAccessQuery())


class ReportInput(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    title: str = Field(min_length=2, max_length=80)
    description: str = Field(min_length=5, max_length=1500)
    category: Literal['路面損壞', '障礙物', '違規占用', '照明問題', '標線與設施', '其他']
    severity: Literal['一般', '注意', '危險']
    lat: float = Field(ge=-90, le=90, allow_inf_nan=False)
    lng: float = Field(ge=-180, le=180, allow_inf_nan=False)
    accuracy: float | None = Field(default=None, ge=0, allow_inf_nan=False)
    locationSource: Literal['gps', 'photo_exif', 'manual']

class BodyLimit:
    """Bound uploads even when the client omits Content-Length."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http' or scope['method'] not in ('POST', 'PUT', 'PATCH'):
            return await self.app(scope, receive, send)
        size, chunks = 0, []
        while True:
            message = await receive()
            if message['type'] == 'http.disconnect':
                return
            size += len(message.get('body', b''))
            if size > MAX_BODY:
                return await JSONResponse({'error': '上傳總大小不可超過 6 MB。'}, status_code=413)(scope, receive, send)
            chunks.append(message.get('body', b''))
            if not message.get('more_body', False):
                break
        used = False
        async def replay():
            nonlocal used
            if not used:
                used = True
                return {'type': 'http.request', 'body': b''.join(chunks), 'more_body': False}
            return await receive()
        await self.app(scope, replay, send)

def connect(path: Path):
    conn = sqlite3.connect(path, timeout=20)
    conn.row_factory = sqlite3.Row
    return conn

def public_report(row, bikeways=None):
    item = dict(row)
    item.pop('photo_key', None)
    item.pop('manage_key_hash', None)
    item.pop('owner_user_id', None)
    item['updatedAt'] = item.get('updatedAt') or item['createdAt']
    item['photoUrl'] = '/api/photos/' + item['id']
    if bikeways is not None:
        item['bikewayMatch'] = bikeways.match(item['lat'],item['lng'],item.get('accuracy'))
    return item

def geojson(items, base_url):
    features = []
    for item in items:
        props = {k: v for k, v in item.items() if k not in ('lat', 'lng')}
        props['photoUrl'] = base_url.rstrip('/') + props['photoUrl']
        features.append({'type': 'Feature', 'id': item['id'],
                         'geometry': {'type': 'Point', 'coordinates': [item['lng'], item['lat']]},
                         'properties': props})
    return {'type': 'FeatureCollection', 'schema_version': '1.0',
            'exported_at': datetime.now(timezone.utc).isoformat(),
            'coordinate_reference_system': 'WGS84 / EPSG:4326',
            'government_delivery_status': 'not_submitted', 'features': features}

def sanitize_photo(data: bytes) -> bytes:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(BytesIO(data)) as image:
                image = ImageOps.exif_transpose(image)
                image.thumbnail((1600, 1600))
                image = image.convert('RGB')
                out = BytesIO()
                image.save(out, format='JPEG', quality=85)
                return out.getvalue()
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise HTTPException(400, '無法讀取照片，請使用有效且尺寸適中的影像。')

def create_app(data_dir: str | Path | None = None, frontend_dir: str | Path | None = None) -> FastAPI:
    directory = Path(data_dir or os.getenv('DATA_DIR', str(ROOT / 'data'))).resolve()
    uploads, database = directory / 'uploads', directory / 'cyclewatch.sqlite3'
    frontend = Path(frontend_dir or ROOT / 'frontend' / 'dist').resolve()
    bikeways=load_index(str(Path(os.getenv('BIKEWAY_DATA_DIR',str(ROOT/'datasets'))).resolve()),float(os.getenv('BIKEWAY_BUFFER_METERS','20')))
    def to_public(row):
        return public_report(row,bikeways)
    username, password = os.getenv('APP_USER', ''), os.getenv('APP_PASSWORD', '')
    if bool(username) != bool(password):
        raise RuntimeError('APP_USER and APP_PASSWORD must both be set or both be empty.')

    auth_mode = os.getenv('AUTH_MODE', 'receipt')
    if auth_mode not in ('receipt', 'google', 'line', 'dual'):
        raise RuntimeError('AUTH_MODE must be receipt, google, line or dual.')
    google_mode = auth_mode != 'receipt'
    if google_mode and username:
        raise RuntimeError('Disable APP_USER / APP_PASSWORD when using account login.')

    @asynccontextmanager
    async def lifespan(_app):
        uploads.mkdir(parents=True, exist_ok=True)
        with connect(database) as conn:
            conn.execute('PRAGMA journal_mode=WAL')
            conn.execute('''CREATE TABLE IF NOT EXISTS reports (
                id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL,
                category TEXT NOT NULL, severity TEXT NOT NULL, status TEXT NOT NULL,
                lat REAL NOT NULL, lng REAL NOT NULL, accuracy REAL,
                locationSource TEXT NOT NULL, photo_key TEXT NOT NULL, createdAt TEXT NOT NULL)''')
            columns = {r['name'] for r in conn.execute('PRAGMA table_info(reports)')}
            if 'manage_key_hash' not in columns:
                conn.execute('ALTER TABLE reports ADD COLUMN manage_key_hash TEXT')
            if 'updatedAt' not in columns:
                conn.execute('ALTER TABLE reports ADD COLUMN updatedAt TEXT')
            if 'owner_user_id' not in columns:
                conn.execute('ALTER TABLE reports ADD COLUMN owner_user_id TEXT')
            conn.execute('CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY,email TEXT NOT NULL,name TEXT NOT NULL,createdAt TEXT NOT NULL)')
            conn.execute('CREATE TABLE IF NOT EXISTS auth_identities (provider TEXT NOT NULL,subject TEXT NOT NULL,user_id TEXT NOT NULL,createdAt TEXT NOT NULL,PRIMARY KEY(provider,subject),UNIQUE(user_id,provider))')
            conn.execute("INSERT OR IGNORE INTO auth_identities SELECT 'google',id,id,createdAt FROM users WHERE id NOT LIKE 'account:%' AND id NOT LIKE 'line:%'")
        yield

    api = FastAPI(title='騎路 CycleWatch API', version='1.4.0', lifespan=lifespan)
    api.add_middleware(BodyLimit)
    current_user = configure_google(api, database, connect, google_mode)

    def require_user(request):
        user = current_user(request)
        if not user:
            raise HTTPException(401, '請先使用 LINE 或 Google 帳號登入。')
        return user

    @api.get('/api/auth/me')
    def me(request: Request):
        user = current_user(request) if google_mode else None
        return {'mode': auth_mode, 'authenticated': bool(user), 'user': {'name': user['name'], 'email': user['email'], 'providers': user.get('providers',[])} if user else None, 'providers': api.state.auth_providers, 'liffId': api.state.liff_id}

    @api.get('/api/my-reports')
    def my_account_reports(request: Request):
        user = require_user(request)
        with connect(database) as conn:
            rows = conn.execute('SELECT * FROM reports WHERE owner_user_id=? ORDER BY createdAt DESC', (user['id'],)).fetchall()
        return {'reports': [to_public(row) for row in rows]}


    @api.middleware('http')
    async def security(request: Request, call_next):
        if username:
            try:
                scheme, value = request.headers.get('authorization', '').split(' ', 1)
                supplied = base64.b64decode(value, validate=True).decode('utf-8') if scheme.lower() == 'basic' else ''
                user, secret = supplied.split(':', 1)
                valid = hmac.compare_digest(user.encode(), username.encode()) & hmac.compare_digest(secret.encode(), password.encode())
            except (ValueError, UnicodeError, binascii.Error):
                valid = False
            if not valid:
                return JSONResponse({'error': '請先登入。'}, status_code=401,
                                    headers={'WWW-Authenticate': 'Basic realm="CycleWatch", charset="UTF-8"'})
        if request.method in ('POST', 'PATCH', 'DELETE'):
            origin = request.headers.get('origin')
            host = request.headers.get('host', '')
            if google_mode and not origin:
                return JSONResponse({'error': '缺少來源驗證。'}, status_code=403)
            if origin and origin not in (f'http://{host}', f'https://{host}'):
                return JSONResponse({'error': '不允許跨網站送出回報。'}, status_code=403)
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        if request.url.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @api.exception_handler(HTTPException)
    async def http_error(_request, exc):
        return JSONResponse({'error': exc.detail}, status_code=exc.status_code, headers=exc.headers)

    @api.get('/api/bikeways')
    def bikeway_layer():
        if not bikeways.available:
            raise HTTPException(503,'官方自行車道圖資未載入，請檢查 datasets 目錄。')
        return bikeways.collection

    @api.get('/api/bikeways/boundary')
    def city_boundary():
        if not bikeways.available:raise HTTPException(503,'臺北市界圖資未載入。')
        return bikeways.boundary_collection

    @api.get('/api/bikeways/match')
    def match_bikeway(lat:float=Query(...,ge=-90,le=90,allow_inf_nan=False),
                      lng:float=Query(...,ge=-180,le=180,allow_inf_nan=False),
                      accuracy:float|None=Query(None,ge=0,allow_inf_nan=False)):
        return {'match':bikeways.match(lat,lng,accuracy)}

    @api.get('/api/health')
    def health():
        with connect(database) as conn:
            conn.execute('SELECT 1')
        return {'status': 'ok', 'version': '1.4.0', 'government_connected': False}

    @api.get('/api/reports')
    def reports():
        with connect(database) as conn:
            rows = conn.execute('SELECT * FROM reports ORDER BY createdAt DESC').fetchall()
        return {'reports': [to_public(row) for row in rows]}

    @api.post('/api/reports', status_code=201)
    def add_report(request: Request, report: str = Form(...), photo: UploadFile = File(...)):
        owner = require_user(request) if google_mode else None
        try:
            parsed = ReportInput.model_validate_json(report)
        except ValidationError:
            raise HTTPException(400, '請確認標題、說明、問題分類與有效座標。')
        photo_data = photo.file.read(MAX_PHOTO + 1)
        if not photo_data or len(photo_data) > MAX_PHOTO:
            raise HTTPException(400, '照片不可為空，且須在 4 MB 以下。')
        photo_data = sanitize_photo(photo_data)
        identifier = str(uuid4())
        key = identifier + '.jpg'
        path = uploads / key
        owner_key = secrets.token_urlsafe(32)
        now = datetime.now(timezone.utc).isoformat()
        row = dict(id=identifier, **parsed.model_dump(), status='待確認', photo_key=key,
                   createdAt=now, updatedAt=now, owner_user_id=owner['id'] if owner else None,
                   manage_key_hash=None if owner else hashlib.sha256(owner_key.encode()).hexdigest())
        try:
            path.write_bytes(photo_data)
            with connect(database) as conn:
                fields = ','.join(row)
                slots = ','.join('?' for _ in row)
                conn.execute(f'INSERT INTO reports ({fields}) VALUES ({slots})', tuple(row.values()))
        except Exception:
            path.unlink(missing_ok=True)
            log.exception('Failed to store report')
            raise HTTPException(500, '回報未儲存，請稍後重試。')
        return {'report': to_public(row), 'ownershipKey': None if owner else owner_key}

    def owned_row(conn, identifier, request):
        row = conn.execute('SELECT * FROM reports WHERE id=?', (identifier,)).fetchone()
        if not row:
            raise HTTPException(404, '此回報已刪除或不存在。')
        if row['owner_user_id']:
            user = require_user(request)
            if row['owner_user_id'] != user['id']:
                raise HTTPException(403, '只能管理自己帳號的回報。')
            return dict(row)
        if google_mode:
            raise HTTPException(403, '請先登入並匯入原私人備份，將舊回報綁定到帳號。')
        supplied = request.headers.get('x-report-key', '')
        expected = row['manage_key_hash'] or ''
        if not supplied or not expected or not hmac.compare_digest(hashlib.sha256(supplied.encode()).hexdigest(), expected):
            raise HTTPException(403, '缺少有效管理憑證，無法修改或刪除此回報。')
        return dict(row)

    @api.post('/api/reports/{identifier}/claim')
    def claim_report(identifier: str, request: Request):
        user = require_user(request)
        with connect(database) as conn:
            conn.execute('BEGIN IMMEDIATE')
            row = conn.execute('SELECT * FROM reports WHERE id=?', (identifier,)).fetchone()
            if not row:
                raise HTTPException(404, '回報不存在。')
            if row['owner_user_id']:
                if row['owner_user_id'] == user['id']:
                    return {'report': to_public(row)}
                raise HTTPException(403, '此回報已綁定其他帳號。')
            key = request.headers.get('x-report-key', '')
            expected = row['manage_key_hash'] or ''
            if not key or not expected or not hmac.compare_digest(hashlib.sha256(key.encode()).hexdigest(), expected):
                raise HTTPException(403, '原私人備份管理憑證無效，無法綁定。')
            conn.execute('UPDATE reports SET owner_user_id=?,manage_key_hash=NULL WHERE id=?', (user['id'], identifier))
            row = dict(row)
            row['owner_user_id'], row['manage_key_hash'] = user['id'], None
        return {'report': to_public(row)}

    @api.get('/api/reports/{identifier}/manage')
    def my_report(identifier: str, request: Request):
        with connect(database) as conn:
            row = owned_row(conn, identifier, request)
        return {'report': to_public(row)}

    @api.patch('/api/reports/{identifier}')
    def edit_report(identifier: str, request: Request, report: str = Form(...), photo: UploadFile | None = File(None)):
        new_path = None
        old_key = None
        try:
            with connect(database) as conn:
                conn.execute('BEGIN IMMEDIATE')
                row = owned_row(conn, identifier, request)
                try:
                    parsed = ReportInput.model_validate_json(report)
                except ValidationError:
                    raise HTTPException(400, '請確認標題、說明與有效座標。')
                row.update(parsed.model_dump())
                row['updatedAt'] = datetime.now(timezone.utc).isoformat()
                if photo is not None:
                    raw = photo.file.read(MAX_PHOTO + 1)
                    if not raw or len(raw) > MAX_PHOTO:
                        raise HTTPException(400, '照片不可為空，且須在 4 MB 以下。')
                    processed = sanitize_photo(raw)
                    old_key = row['photo_key']
                    row['photo_key'] = identifier + '-' + uuid4().hex + '.jpg'
                    new_path = uploads / row['photo_key']
                    new_path.write_bytes(processed)
                fields = list(parsed.model_dump()) + ['updatedAt', 'photo_key']
                conn.execute('UPDATE reports SET ' + ','.join(f'{name}=?' for name in fields) + ' WHERE id=?',
                             tuple(row[name] for name in fields) + (identifier,))
        except Exception:
            if new_path:
                new_path.unlink(missing_ok=True)
            raise
        if old_key:
            try:
                (uploads / old_key).unlink(missing_ok=True)
            except OSError:
                log.exception('Could not remove replaced photo')
        return {'report': to_public(row)}

    @api.delete('/api/reports/{identifier}')
    def delete_report(identifier: str, request: Request):
        with connect(database) as conn:
            conn.execute('BEGIN IMMEDIATE')
            row = owned_row(conn, identifier, request)
            conn.execute('DELETE FROM reports WHERE id=?', (identifier,))
        try:
            (uploads / row['photo_key']).unlink(missing_ok=True)
        except OSError:
            log.exception('Could not remove deleted report photo')
        return {'deleted': True, 'id': identifier}

    @api.get('/api/photos/{identifier}')
    def get_photo(identifier: str):
        try:
            if str(UUID(identifier)) != identifier:
                raise ValueError()
        except ValueError:
            raise HTTPException(404, '找不到照片。')
        with connect(database) as conn:
            row = conn.execute('SELECT photo_key FROM reports WHERE id=?', (identifier,)).fetchone()
        if not row:
            raise HTTPException(404, '找不到照片。')
        path = uploads / row['photo_key']
        if not path.is_file():
            raise HTTPException(404, '找不到照片。')
        return FileResponse(path, media_type='image/jpeg')

    @api.get('/api/export')
    def export(request: Request):
        with connect(database) as conn:
            items = [to_public(row) for row in conn.execute('SELECT * FROM reports ORDER BY createdAt DESC').fetchall()]
        origin = os.getenv('PUBLIC_BASE_URL', '').rstrip('/') or str(request.base_url).rstrip('/')
        return JSONResponse(geojson(items, origin), media_type='application/geo+json',
                            headers={'Content-Disposition': 'attachment; filename="cyclewatch.json"'})

    @api.get('/api/{unknown:path}')
    def unknown_api(unknown: str):
        raise HTTPException(404, '找不到 API。')

    if frontend.is_dir():
        api.mount('/', StaticFiles(directory=frontend, html=True), name='frontend')
    else:
        @api.get('/')
        def build_hint():
            return JSONResponse({'message': '請先在 frontend 執行 npm ci && npm run build，然後重啟後端。', 'api_docs': '/docs'}, status_code=503)
    return api

app = create_app()
