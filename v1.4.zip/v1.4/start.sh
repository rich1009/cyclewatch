#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
PYTHON_BIN="${PYTHON_BIN:-python3}"
if [ ! -f frontend/dist/index.html ]; then
  echo '缺少前端檔案，請先執行：cd frontend && npm ci && npm run build' >&2
  exit 1
fi
exec "$PYTHON_BIN" -m uvicorn backend.app:app --host "${HOST:-127.0.0.1}" --port "${PORT:-8000}"
