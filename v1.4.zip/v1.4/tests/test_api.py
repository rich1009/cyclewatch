from io import BytesIO
import json
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from PIL import Image
import pytest
from backend.app import create_app, MAX_BODY

@pytest.fixture
def report():
    return {'title':'路面破損','description':'右側自行車道有坑洞。','category':'路面損壞',
            'severity':'危險','lat':25.05,'lng':121.55,'accuracy':8,'locationSource':'gps'}

@pytest.fixture
def photo():
    out=BytesIO()
    image=Image.new('RGB',(20,20),'green')
    exif=Image.Exif();exif[270]='private metadata'
    image.save(out,format='JPEG',exif=exif)
    return out.getvalue()

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.delenv('APP_USER',raising=False);monkeypatch.delenv('APP_PASSWORD',raising=False)
    with TestClient(create_app(tmp_path/'data')) as c:
        yield c

def upload(client,report,photo,**kwargs):
    return client.post('/api/reports',data={'report':json.dumps(report)},files={'photo':('image.jpg',photo,'image/jpeg')},**kwargs)

def test_end_to_end(client,report,photo):
    assert client.get('/api/health').json()['government_connected'] is False
    assert client.get('/api/reports').json()=={'reports':[]}
    res=upload(client,report,photo)
    assert res.status_code==201,res.text
    item=res.json()['report'];assert item['status']=='待確認'
    assert 'photo_key' not in item
    saved=client.get('/api/reports').json()['reports'];assert saved==[item]
    image=client.get(item['photoUrl'])
    assert image.status_code==200 and image.headers['content-type']=='image/jpeg'
    assert len(Image.open(BytesIO(image.content)).getexif())==0
    exported=client.get('/api/export').json()
    assert exported['features'][0]['geometry']['coordinates']==[121.55,25.05]
    assert exported['government_delivery_status']=='not_submitted'
    assert exported['features'][0]['properties']['photoUrl'].startswith('http://testserver/api/photos/')

@pytest.mark.parametrize('change',[{'lat':91},{'lng':-181},{'severity':'未知'},{'description':'短'},{'accuracy':-1},{'status':'已修復'}])
def test_reject_invalid(client,report,photo,change):
    assert upload(client,{**report,**change},photo).status_code==400
    assert client.get('/api/reports').json()['reports']==[]

def test_bad_photo(client,report):
    assert upload(client,report,b'\xff\xd8\xffnot really jpeg').status_code==400

def test_body_limit(client):
    assert client.post('/api/reports',content=b'x'*(MAX_BODY+1)).status_code==413

def test_cross_origin(client,report,photo):
    assert upload(client,report,photo,headers={'Origin':'https://elsewhere.example'}).status_code==403
    assert upload(client,report,photo,headers={'Origin':'http://testserver'}).status_code==201

def test_persistence(tmp_path,report,photo,monkeypatch):
    monkeypatch.delenv('APP_USER',raising=False);monkeypatch.delenv('APP_PASSWORD',raising=False)
    with TestClient(create_app(tmp_path)) as c:
        identifier=upload(c,report,photo).json()['report']['id']
    with TestClient(create_app(tmp_path)) as c:
        assert c.get('/api/reports').json()['reports'][0]['id']==identifier
        assert c.get('/api/photos/'+identifier).status_code==200

def test_auth(tmp_path,monkeypatch):
    monkeypatch.setenv('APP_USER','tester');monkeypatch.setenv('APP_PASSWORD','test-password')
    with TestClient(create_app(tmp_path)) as c:
        assert c.get('/api/reports').status_code==401
        assert c.get('/api/reports',auth=('tester','wrong')).status_code==401
        assert c.get('/api/reports',auth=('tester','test-password')).status_code==200
        assert c.get('/api/photos/bad').status_code==401

def test_unknown_photo(client):
    assert client.get('/api/photos/not-an-id').status_code==404
    assert client.get('/api/photos/00000000-0000-0000-0000-000000000000').status_code==404
    assert client.get('/api/nonexistent').status_code==404

def test_static_frontend(tmp_path,monkeypatch):
    monkeypatch.delenv('APP_USER',raising=False);monkeypatch.delenv('APP_PASSWORD',raising=False)
    dist=Path(__file__).resolve().parent.parent/'frontend'/'dist'
    if not dist.is_dir(): pytest.skip('Build frontend first')
    with TestClient(create_app(tmp_path,dist)) as c:
        response=c.get('/')
        assert response.status_code==200 and '<div id="root">' in response.text
        assert response.headers['referrer-policy']=='strict-origin-when-cross-origin'
        import re
        for asset in re.findall(r'(?:src|href)="([^"]+)"', response.text):
            assert c.get(asset).status_code==200,asset

def test_owner_edit_delete(client,report,photo,tmp_path):
    created=upload(client,report,photo).json()
    item=created['report'];key=created['ownershipKey'];headers={'X-Report-Key':key}
    assert 'manage_key_hash' not in item and 'ownershipKey' not in item
    assert client.patch('/api/reports/'+item['id'],data={'report':json.dumps(report)}).status_code==403
    assert client.delete('/api/reports/'+item['id']).status_code==403
    assert client.delete('/api/reports/'+item['id'],headers={'X-Report-Key':'wrong'}).status_code==403
    assert client.get('/api/reports/'+item['id']+'/manage',headers=headers).status_code==200
    edited={**report,'title':'更新後的坑洞回報','lat':25.06}
    result=client.patch('/api/reports/'+item['id'],data={'report':json.dumps(edited)},headers=headers)
    assert result.status_code==200,result.text
    updated=result.json()['report'];assert updated['title']==edited['title'] and updated['lat']==25.06
    assert updated['createdAt']==item['createdAt'] and updated['updatedAt']>=item['createdAt']
    assert client.get(updated['photoUrl']).status_code==200
    assert key not in client.get('/api/reports').text
    assert 'manage_key_hash' not in client.get('/api/export').text
    assert key not in client.get('/api/export').text
    assert client.delete('/api/reports/'+item['id'],headers=headers).status_code==200
    assert client.get('/api/reports').json()['reports']==[]
    assert client.get(updated['photoUrl']).status_code==404
    assert not list((tmp_path/'data'/'uploads').glob('*.jpg'))
    assert client.get('/api/reports/'+item['id']+'/manage',headers=headers).status_code==404

def test_one_owner_key_cannot_edit_another(client,report,photo):
    a=upload(client,report,photo).json();b=upload(client,report,photo).json()
    headers={'X-Report-Key':a['ownershipKey']}
    assert client.patch('/api/reports/'+b['report']['id'],data={'report':json.dumps(report)},headers=headers).status_code==403
    assert client.delete('/api/reports/'+b['report']['id'],headers=headers).status_code==403

def test_owner_photo_replacement(client,report,photo,tmp_path):
    created=upload(client,report,photo).json();identifier=created['report']['id']
    original=tmp_path/'data'/'uploads'/(identifier+'.jpg')
    image=BytesIO();Image.new('RGB',(30,30),'red').save(image,format='PNG')
    result=client.patch('/api/reports/'+identifier,headers={'X-Report-Key':created['ownershipKey']},data={'report':json.dumps(report)},files={'photo':('replace.png',image.getvalue(),'image/png')})
    assert result.status_code==200,result.text
    assert not original.exists()
    assert len(list((tmp_path/'data'/'uploads').glob('*.jpg')))==1
    response=client.get(result.json()['report']['photoUrl'])
    img=Image.open(BytesIO(response.content))
    assert img.size==(30,30) and img.getpixel((0,0))[0]>200

def test_legacy_migration(tmp_path,monkeypatch,report):
    import sqlite3
    monkeypatch.delenv('APP_USER',raising=False);monkeypatch.delenv('APP_PASSWORD',raising=False)
    tmp_path.mkdir(exist_ok=True)
    conn=sqlite3.connect(tmp_path/'cyclewatch.sqlite3')
    conn.execute('''CREATE TABLE reports (id TEXT PRIMARY KEY,title TEXT,description TEXT,category TEXT,severity TEXT,status TEXT,lat REAL,lng REAL,accuracy REAL,locationSource TEXT,photo_key TEXT,createdAt TEXT)''')
    conn.execute('INSERT INTO reports VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',('00000000-0000-0000-0000-000000000001',report['title'],report['description'],report['category'],report['severity'],'待確認',report['lat'],report['lng'],8,'gps','legacy.jpg','2026-10-18T00:00:00Z'))
    conn.commit();conn.close()
    with TestClient(create_app(tmp_path)) as c:
        assert len(c.get('/api/reports').json()['reports'])==1
        assert c.delete('/api/reports/00000000-0000-0000-0000-000000000001',headers={'X-Report-Key':'invented-key'}).status_code==403
    with TestClient(create_app(tmp_path)) as c:
        assert len(c.get('/api/reports').json()['reports'])==1

def test_invalid_owner_edit_preserves_original(client,report,photo):
    created=upload(client,report,photo).json();identifier=created['report']['id'];headers={'X-Report-Key':created['ownershipKey']}
    assert client.patch('/api/reports/'+identifier,headers=headers,data={'report':json.dumps({**report,'lat':100})}).status_code==400
    assert client.patch('/api/reports/'+identifier,headers=headers,data={'report':json.dumps(report)},files={'photo':('bad.jpg',b'bad','image/jpeg')}).status_code==400
    assert client.get('/api/reports/'+identifier+'/manage',headers=headers).json()['report']==created['report']
    assert client.get(created['report']['photoUrl']).status_code==200
    assert client.delete('/api/reports/'+identifier,headers={**headers,'Origin':'https://elsewhere.example'}).status_code==403

def test_owner_key_survives_restart(tmp_path,monkeypatch,report,photo):
    monkeypatch.delenv('APP_USER',raising=False);monkeypatch.delenv('APP_PASSWORD',raising=False)
    with TestClient(create_app(tmp_path)) as c:
        data=upload(c,report,photo).json()
    with TestClient(create_app(tmp_path)) as c:
        assert c.get('/api/reports/'+data['report']['id']+'/manage',headers={'X-Report-Key':data['ownershipKey']}).status_code==200
