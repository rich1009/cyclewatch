import json
from pathlib import Path
import csv
from io import BytesIO
from datetime import date

import pytest
from pyproj import Transformer
from shapely.geometry import LineString,Polygon,mapping,shape
from shapely import transform
from PIL import Image
from fastapi.testclient import TestClient

from backend.bikeways import BikewayIndex
from backend.app import create_app
from scripts.build_bikeways import xy_parts,completed_on

ROOT=Path(__file__).resolve().parent.parent

@pytest.fixture
def synthetic_dataset(tmp_path):
    # A 200m route in a 400m city square, all defined in a metre-based CRS.
    x,y=305000,2770000
    to_wgs=Transformer.from_crs(3826,4326,always_xy=True)
    line=LineString([(x-100,y),(x+100,y)])
    boundary=Polygon([(x-200,y-200),(x+200,y-200),(x+200,y+200),(x-200,y+200)])
    feature={'type':'Feature','id':'synthetic:1','properties':{'route_id':'synthetic:1','name':'測試路段','kind':'urban','maintainer':'測試管養單位','publisher':'測試來源','source_url':'https://example.test'},'geometry':mapping(transform(line,to_wgs.transform,interleaved=False))}
    data={'type':'FeatureCollection','features':[feature],'metadata':{'dataset_version':'test-v1','retrieved_on':'2026-10-21','counts':{'urban':1,'riverside':0},'feature_count':1}}
    (tmp_path/'taipei-bikeways.geojson').write_text(json.dumps(data))
    (tmp_path/'taipei-boundary.geojson').write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','properties':{},'geometry':mapping(transform(boundary,to_wgs.transform,interleaved=False))}]}))
    def point(dx,dy):
        lng,lat=to_wgs.transform(x+dx,y+dy)
        return lat,lng
    return tmp_path,point

def test_metric_distance_scope_and_uncertainty(synthetic_dataset):
    folder,point=synthetic_dataset;b=BikewayIndex(folder,20)
    assert b.available
    matched=b.match(*point(0,15))
    assert matched['status']=='matched' and matched['distance_m']==pytest.approx(15,abs=.1)
    assert matched['priority_candidate'] is True and matched['government_priority_confirmed'] is False
    assert b.match(*point(0,25))['status']=='unmatched'
    assert b.match(*point(0,19),accuracy=5)['status']=='needs_review'
    assert b.match(*point(0,0),accuracy=80)['status']=='needs_review'
    assert b.match(*point(250,0))['status']=='outside_taipei'
    assert b.match(*point(0,195),accuracy=10)['status']=='needs_review'
    assert b.match(0,0)['status']=='outside_taipei'

def test_official_data_counts_and_city_clipping():
    b=BikewayIndex(ROOT/'datasets')
    assert b.available
    assert b.metadata['counts']=={'urban':478,'riverside':7}
    assert b.metadata['input_urban_records']==478
    assert len(b.lines)==485
    assert b.metadata['license']['url']=='https://data.gov.tw/license'
    assert len({f['id'] for f in b.collection['features']})==485
    for line in b.lines:
        assert b.boundary.buffer(.01).covers(line)
    # Source coordinates transform to valid Taipei longitude / latitude, not swapped.
    for feature in b.collection['features']:
        box=shape(feature['geometry']).bounds
        assert 121<box[0]<122 and 24<box[1]<26


def test_xy_multipart_never_bridges_gaps():
    identity=Transformer.from_crs(4326,4326,always_xy=True)
    parts=xy_parts('121.5,121.51#121.6,121.61','25,25#25,25',identity)
    assert len(parts)==2 and len(parts[0].coords)==2
    assert parts[0].coords[-1][0]==121.51 and parts[1].coords[0][0]==121.6
    with pytest.raises(ValueError):xy_parts('121.5,121.6','25',identity)
    assert completed_on('1021231')==date(2013,12,31)

def test_api_export_and_edit_use_server_calculated_scope(synthetic_dataset,monkeypatch,tmp_path):
    folder,point=synthetic_dataset
    monkeypatch.setenv('BIKEWAY_DATA_DIR',str(folder))
    monkeypatch.setenv('AUTH_MODE','receipt');monkeypatch.setenv('APP_USER','');monkeypatch.setenv('APP_PASSWORD','')
    with TestClient(create_app(tmp_path/'db')) as c:
        assert c.get('/api/bikeways').status_code==200
        assert c.get('/api/bikeways/boundary').status_code==200
        lat,lng=point(0,0)
        matched=c.get('/api/bikeways/match',params={'lat':lat,'lng':lng}).json()['match']
        assert matched['priority_candidate'] is True
        assert c.get('/api/bikeways/match?lat=91&lng=121').status_code==422
        report={'title':'自行車道坑洞','description':'右側路面出現坑洞。','category':'路面損壞','severity':'危險','lat':lat,'lng':lng,'accuracy':None,'locationSource':'manual'}
        image=BytesIO();Image.new('RGB',(8,8),'red').save(image,format='JPEG')
        def post(data):return c.post('/api/reports',data={'report':json.dumps(data)},files={'photo':('test.jpg',image.getvalue(),'image/jpeg')})
        assert post({**report,'bikewayMatch':{'priority_candidate':True}}).status_code==400
        created=post(report).json()
        assert created['report']['bikewayMatch']['status']=='matched'
        exported=c.get('/api/export').json()['features'][0]['properties']['bikewayMatch']
        assert exported['government_priority_confirmed'] is False and exported['dataset_version']=='test-v1'
        lat,lng=point(0,70)
        updated=c.patch('/api/reports/'+created['report']['id'],headers={'X-Report-Key':created['ownershipKey']},data={'report':json.dumps({**report,'lat':lat,'lng':lng})})
        assert updated.status_code==200,updated.text
        assert updated.json()['report']['bikewayMatch']['status']=='unmatched'

def test_unavailable_data_does_not_claim_out_of_scope(tmp_path,monkeypatch):
    monkeypatch.setenv('BIKEWAY_DATA_DIR',str(tmp_path/'missing'))
    monkeypatch.setenv('AUTH_MODE','receipt');monkeypatch.setenv('APP_USER','');monkeypatch.setenv('APP_PASSWORD','')
    with TestClient(create_app(tmp_path/'db')) as c:
        assert c.get('/api/bikeways').status_code==503
        match=c.get('/api/bikeways/match?lat=25&lng=121').json()['match']
        assert match['status']=='unavailable' and match['inside_taipei'] is None
        assert match['priority_candidate'] is False

@pytest.mark.parametrize('buffer',[0,101,float('nan')])
def test_invalid_threshold_rejected(tmp_path,buffer):
    with pytest.raises(ValueError):BikewayIndex(tmp_path,buffer)
