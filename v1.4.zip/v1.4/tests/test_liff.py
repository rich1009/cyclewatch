import json
import time
from io import BytesIO
from unittest.mock import AsyncMock
from urllib.parse import parse_qs,urlsplit
import httpx
import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from PIL import Image
import backend.google_auth as auth_module
from backend.app import create_app

BASE='https://bike.example.com'
TOKEN='test-id-token-'+'x'*200

@pytest.fixture
def dual_config(monkeypatch):
    config={'AUTH_MODE':'dual','PUBLIC_BASE_URL':BASE,'SESSION_SECRET':'s'*64,'GOOGLE_CLIENT_ID':'test-google','GOOGLE_CLIENT_SECRET':'test-secret','LINE_CHANNEL_ID':'12345','LIFF_ID':'12345-test','APP_USER':'','APP_PASSWORD':''}
    for k,v in config.items():monkeypatch.setenv(k,v)

@pytest.fixture
def dual_client(tmp_path,dual_config):
    app=create_app(tmp_path)
    with TestClient(app,base_url=BASE) as c:yield c,app

def line_info(subject='Uline-a'):
    return {'iss':'https://access.line.me','aud':'12345','exp':int(time.time())+600,'sub':subject,'name':'LINE Tester'}

def login_line(c):
    r=c.post('/api/auth/liff/challenge',headers={'Origin':BASE},json={'link':False})
    assert r.status_code==200,r.text
    return c.post('/api/auth/liff',headers={'Origin':BASE},json={'idToken':TOKEN,'challenge':r.json()['challenge']})

def add_report(c):
    data={'title':'自行車道坑洞','description':'路面右側有坑洞，請注意。','category':'路面損壞','severity':'注意','lat':25,'lng':121,'accuracy':None,'locationSource':'manual'}
    photo=BytesIO();Image.new('RGB',(10,10),'green').save(photo,format='JPEG')
    return c.post('/api/reports',headers={'Origin':BASE},data={'report':json.dumps(data)},files={'photo':('image.jpg',photo.getvalue(),'image/jpeg')})

def google_info(subject='google-a'):
    return {'userinfo':{'sub':subject,'email':'same@example.com','email_verified':True,'name':'Google Tester'}}

def test_line_login_and_public_privacy(dual_client,monkeypatch):
    c,app=dual_client
    mock=AsyncMock(return_value=line_info())
    monkeypatch.setattr(auth_module,'verify_line_token',mock)
    config=c.get('/api/auth/config').json()
    assert config=={'providers':['google','line'],'liffId':'12345-test'}
    assert 'test-secret' not in c.get('/api/auth/config').text
    assert add_report(c).status_code==401
    login_result=login_line(c)
    assert login_result.status_code==200
    assert 'secure' in login_result.headers.get('set-cookie','').lower()
    me=c.get('/api/auth/me').json()
    assert me['user']['providers']==['line'] and me['user']['email']==''
    result=add_report(c);assert result.status_code==201,result.text
    assert len(c.get('/api/my-reports').json()['reports'])==1
    public=c.get('/api/reports').text
    assert 'Uline-a' not in public and 'LINE Tester' not in public and 'owner_user_id' not in public

def test_missing_challenge_and_spoofed_profile_rejected(dual_client,monkeypatch):
    c,app=dual_client;mock=AsyncMock(return_value=line_info());monkeypatch.setattr(auth_module,'verify_line_token',mock)
    assert c.post('/api/auth/liff',headers={'Origin':BASE},json={'idToken':TOKEN,'challenge':'x'*40}).status_code==400
    mock.assert_not_called()
    assert c.post('/api/auth/liff/challenge',headers={'Origin':'https://evil.example'},json={}).status_code==403
    r=c.post('/api/auth/liff/challenge',headers={'Origin':BASE},json={})
    assert c.post('/api/auth/liff',headers={'Origin':BASE},json={'idToken':TOKEN,'challenge':r.json()['challenge'],'userId':'victim'}).status_code==422
    mock.assert_not_called()

@pytest.mark.parametrize('changes',[{'aud':'wrong'},{'iss':'https://evil.example'},{'exp':1},{'sub':''}])
def test_line_claims_are_verified(monkeypatch,changes):
    import asyncio
    original_client=httpx.AsyncClient
    def handler(request):
        assert request.url==httpx.URL('https://api.line.me/oauth2/v2.1/verify')
        assert b'client_id=12345' in request.content and b'id_token=' in request.content
        return httpx.Response(200,json={**line_info(),**changes})
    monkeypatch.setattr(auth_module.httpx,'AsyncClient',lambda **kw:original_client(transport=httpx.MockTransport(handler),trust_env=False))
    with pytest.raises(HTTPException) as error:asyncio.run(auth_module.verify_line_token(TOKEN,'12345'))
    assert error.value.status_code==401

def test_line_verified_endpoint(monkeypatch):
    import asyncio
    original_client=httpx.AsyncClient
    monkeypatch.setattr(auth_module.httpx,'AsyncClient',lambda **kw:original_client(transport=httpx.MockTransport(lambda req:httpx.Response(200,json=line_info())),trust_env=False))
    assert asyncio.run(auth_module.verify_line_token(TOKEN,'12345'))['sub']=='Uline-a'

def test_explicit_google_link_shares_same_reports(dual_client,monkeypatch):
    c,app=dual_client
    monkeypatch.setattr(auth_module,'verify_line_token',AsyncMock(return_value=line_info()))
    assert login_line(c).status_code==200
    report_id=add_report(c).json()['report']['id']
    r=c.post('/api/auth/google/link',headers={'Origin':BASE});assert r.status_code==200
    google=app.state.google_oauth.google
    google.load_server_metadata=AsyncMock(return_value={'authorization_endpoint':'https://accounts.google.com/o/oauth2/v2/auth'})
    redirect=c.get(r.json()['url'],follow_redirects=False)
    state=parse_qs(urlsplit(redirect.headers['location']).query)['state'][0]
    google.authorize_access_token=AsyncMock(return_value=google_info())
    callback=c.get('/api/auth/google/callback?state='+state,follow_redirects=False)
    assert callback.headers['location'].endswith('/?login=success')
    assert c.get('/api/auth/me').json()['user']['providers']==['google','line']
    c.post('/api/auth/logout',headers={'Origin':BASE})
    assert c.get('/api/auth/me').json()['authenticated'] is False
    c.get('/api/auth/google/callback',follow_redirects=False)
    assert c.get('/api/my-reports').json()['reports'][0]['id']==report_id

def test_accounts_do_not_merge_on_same_email_or_unlinked_login(dual_client,monkeypatch):
    c,app=dual_client
    monkeypatch.setattr(auth_module,'verify_line_token',AsyncMock(return_value=line_info()))
    login_line(c);report_id=add_report(c).json()['report']['id']
    c.post('/api/auth/logout',headers={'Origin':BASE})
    app.state.google_oauth.google.authorize_access_token=AsyncMock(return_value=google_info())
    c.get('/api/auth/google/callback',follow_redirects=False)
    assert c.get('/api/my-reports').json()['reports']==[]
    challenge=c.post('/api/auth/liff/challenge',headers={'Origin':BASE},json={'link':True}).json()['challenge']
    assert c.post('/api/auth/liff',headers={'Origin':BASE},json={'idToken':TOKEN,'challenge':challenge}).status_code==409
    assert c.delete('/api/reports/'+report_id,headers={'Origin':BASE}).status_code==403

def test_liff_requires_public_https(tmp_path,dual_config,monkeypatch):
    monkeypatch.setenv('PUBLIC_BASE_URL','http://localhost:18000')
    with pytest.raises(RuntimeError,match='HTTPS'):create_app(tmp_path)

def test_google_login_not_sent_to_line_webview(dual_client):
    c,app=dual_client
    assert c.get('/api/auth/google/login',headers={'User-Agent':'Mozilla/5.0 Line/15.0'},follow_redirects=False).status_code==400

def test_distinct_google_subjects_with_same_email_do_not_merge(dual_client):
    c,app=dual_client
    google=app.state.google_oauth.google
    google.authorize_access_token=AsyncMock(return_value=google_info('google-a'))
    c.get('/api/auth/google/callback',follow_redirects=False)
    report_id=add_report(c).json()['report']['id']
    c.post('/api/auth/logout',headers={'Origin':BASE})
    google.authorize_access_token=AsyncMock(return_value=google_info('google-b'))
    c.get('/api/auth/google/callback',follow_redirects=False)
    assert c.get('/api/my-reports').json()['reports']==[]
    assert c.delete('/api/reports/'+report_id,headers={'Origin':BASE}).status_code==403

def test_google_link_rejects_wrong_state(dual_client,monkeypatch):
    c,app=dual_client
    monkeypatch.setattr(auth_module,'verify_line_token',AsyncMock(return_value=line_info()))
    login_line(c)
    c.post('/api/auth/google/link',headers={'Origin':BASE})
    google=app.state.google_oauth.google
    google.load_server_metadata=AsyncMock(return_value={'authorization_endpoint':'https://accounts.google.com/o/oauth2/v2/auth'})
    c.get('/api/auth/google/login?link=1',follow_redirects=False)
    google.authorize_access_token=AsyncMock(return_value=google_info())
    response=c.get('/api/auth/google/callback?state=wrong',follow_redirects=False)
    assert response.headers['location'].endswith('/?login=failed')

def test_access_log_redacts_query():
    import logging
    from backend.app import RedactAccessQuery
    record=logging.LogRecord('uvicorn.access',logging.INFO,'',1,'%s - "%s %s HTTP/%s" %d',('client','GET','/?access_token=private','1.1',200),None)
    assert RedactAccessQuery().filter(record)
    assert 'private' not in record.getMessage()

def test_v12_google_identity_and_reports_survive_upgrade(tmp_path,dual_config):
    import sqlite3,base64
    from itsdangerous import TimestampSigner
    database=tmp_path/'cyclewatch.sqlite3'
    conn=sqlite3.connect(database)
    conn.execute('CREATE TABLE users (id TEXT PRIMARY KEY,email TEXT NOT NULL,name TEXT NOT NULL,createdAt TEXT NOT NULL)')
    conn.execute('INSERT INTO users VALUES (?,?,?,?)',('legacy-google-sub','legacy@example.com','Legacy','2026-10-18'))
    conn.execute('''CREATE TABLE reports (id TEXT PRIMARY KEY,title TEXT,description TEXT,category TEXT,severity TEXT,status TEXT,lat REAL,lng REAL,accuracy REAL,locationSource TEXT,photo_key TEXT,createdAt TEXT,owner_user_id TEXT)''')
    identifier='00000000-0000-0000-0000-000000000001'
    conn.execute('INSERT INTO reports VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',(identifier,'舊回報','舊版已存在的回報','路面損壞','注意','待確認',25,121,None,'manual','old.jpg','2026-10-18','legacy-google-sub'))
    conn.commit();conn.close()
    app=create_app(tmp_path)
    with TestClient(app,base_url=BASE) as c:
        signed=TimestampSigner('s'*64).sign(base64.b64encode(json.dumps({'uid':'legacy-google-sub'}).encode())).decode()
        c.cookies.set('cyclewatch_session',signed,domain='bike.example.com',path='/')
        assert c.get('/api/auth/me').json()['user']['providers']==['google']
        assert c.get('/api/my-reports').json()['reports'][0]['id']==identifier
        app.state.google_oauth.google.authorize_access_token=AsyncMock(return_value=google_info('legacy-google-sub'))
        assert c.get('/api/auth/google/callback',follow_redirects=False).headers['location'].endswith('/?login=success')
        assert c.get('/api/my-reports').json()['reports'][0]['id']==identifier
