import base64
import json
import sqlite3
from urllib.parse import urlsplit,parse_qs
from unittest.mock import AsyncMock
import pytest
from fastapi.testclient import TestClient
from itsdangerous import TimestampSigner
from backend.app import create_app

SECRET='t'*64
ORIGIN='http://localhost:18000'

def cookie(uid):
    payload=base64.b64encode(json.dumps({'uid':uid}).encode())
    return TimestampSigner(SECRET).sign(payload).decode()

@pytest.fixture
def google_config(monkeypatch):
    for k,v in {'AUTH_MODE':'google','GOOGLE_CLIENT_ID':'test-client.apps.googleusercontent.com','GOOGLE_CLIENT_SECRET':'test-secret','SESSION_SECRET':SECRET,'PUBLIC_BASE_URL':ORIGIN,'APP_USER':'','APP_PASSWORD':''}.items():monkeypatch.setenv(k,v)

@pytest.fixture
def google_client(tmp_path,google_config):
    app=create_app(tmp_path)
    with TestClient(app,base_url=ORIGIN) as client:
        with sqlite3.connect(tmp_path/'cyclewatch.sqlite3') as conn:
            for uid in ('account-a','account-b'):
                conn.execute('INSERT INTO users VALUES (?,?,?,?)',(uid,uid+'@example.com',uid,'2026-10-19T00:00:00Z'))
        yield client,app

def report():
    return {'title':'車道坑洞','description':'車道右側有一個坑洞。','category':'路面損壞','severity':'注意','lat':25,'lng':121,'accuracy':None,'locationSource':'manual'}

def photo():
    from PIL import Image
    from io import BytesIO
    data=BytesIO();Image.new('RGB',(8,8),'blue').save(data,format='JPEG');return data.getvalue()

def upload(c):
    return c.post('/api/reports',headers={'Origin':ORIGIN},data={'report':json.dumps(report())},files={'photo':('image.jpg',photo(),'image/jpeg')})

def test_google_account_isolation(google_client):
    c,app=google_client
    assert c.get('/api/reports').status_code==200
    assert upload(c).status_code==401
    c.cookies.set('cyclewatch_session',cookie('account-a'),domain='localhost.local',path='/')
    assert c.get('/api/auth/me').json()['user']['email']=='account-a@example.com'
    made=upload(c);assert made.status_code==201,made.text
    data=made.json();identifier=data['report']['id'];assert data['ownershipKey'] is None
    assert 'owner_user_id' not in data['report']
    assert len(c.get('/api/my-reports').json()['reports'])==1
    assert 'account-a' not in c.get('/api/reports').text
    c.cookies.clear();c.cookies.set('cyclewatch_session',cookie('account-b'),domain='localhost.local',path='/')
    assert c.get('/api/my-reports').json()['reports']==[]
    assert c.patch('/api/reports/'+identifier,headers={'Origin':ORIGIN},data={'report':json.dumps(report())}).status_code==403
    assert c.delete('/api/reports/'+identifier,headers={'Origin':ORIGIN}).status_code==403
    c.cookies.clear();c.cookies.set('cyclewatch_session',cookie('account-a'),domain='localhost.local',path='/')
    edited={**report(),'title':'已更新的坑洞資訊'}
    assert c.patch('/api/reports/'+identifier,headers={'Origin':ORIGIN},data={'report':json.dumps(edited)}).json()['report']['title']==edited['title']
    assert c.delete('/api/reports/'+identifier,headers={'Origin':ORIGIN}).status_code==200

def test_bad_cookie_csrf_and_logout(google_client):
    c,app=google_client
    c.cookies.set('cyclewatch_session',cookie('account-a')+'tampered',domain='localhost.local',path='/')
    assert c.get('/api/auth/me').json()['authenticated'] is False
    c.cookies.clear();c.cookies.set('cyclewatch_session',cookie('account-a'),domain='localhost.local',path='/')
    assert c.post('/api/auth/logout').status_code==403
    assert c.post('/api/auth/logout',headers={'Origin':'https://evil.example'}).status_code==403
    assert c.post('/api/auth/logout',headers={'Origin':ORIGIN}).status_code==200
    assert c.get('/api/auth/me').json()['authenticated'] is False

def test_login_redirect_has_state_nonce_pkce(google_client):
    c,app=google_client
    google=app.state.google_oauth.google
    google.load_server_metadata=AsyncMock(return_value={'authorization_endpoint':'https://accounts.google.com/o/oauth2/v2/auth'})
    response=c.get('/api/auth/google/login',follow_redirects=False)
    assert response.status_code==302,response.text
    params=parse_qs(urlsplit(response.headers['location']).query)
    assert params['redirect_uri']==[ORIGIN+'/api/auth/google/callback']
    assert params['code_challenge_method']==['S256']
    assert params['state'][0] and params['nonce'][0]
    assert 'httponly' in response.headers['set-cookie'].lower()

def test_invalid_callback_does_not_exchange_token(google_client):
    c,app=google_client
    app.state.google_oauth.google.fetch_access_token=AsyncMock()
    response=c.get('/api/auth/google/callback?state=invalid&code=fake',follow_redirects=False)
    assert response.status_code==303 and response.headers['location'].endswith('/?login=failed')
    app.state.google_oauth.google.fetch_access_token.assert_not_called()

def test_simulated_verified_callback_and_unverified_rejection(google_client):
    c,app=google_client
    app.state.google_oauth.google.authorize_access_token=AsyncMock(return_value={'userinfo':{'sub':'google-subject-new','email':'new@example.com','name':'New User','email_verified':True},'access_token':'must-not-persist'})
    response=c.get('/api/auth/google/callback',follow_redirects=False)
    assert response.status_code==303 and response.headers['location'].endswith('/?login=success')
    assert 'must-not-persist' not in response.headers.get('set-cookie','')
    assert c.get('/api/auth/me').json()['user']['name']=='New User'
    app.state.google_oauth.google.authorize_access_token=AsyncMock(return_value={'userinfo':{'sub':'evil','email':'bad@example.com','email_verified':False}})
    assert c.get('/api/auth/google/callback',follow_redirects=False).headers['location'].endswith('/?login=failed')
    assert c.get('/api/auth/me').json()['authenticated'] is False

def test_google_requires_complete_configuration(monkeypatch,tmp_path):
    monkeypatch.setenv('AUTH_MODE','google');monkeypatch.setenv('APP_USER','');monkeypatch.setenv('APP_PASSWORD','')
    monkeypatch.delenv('GOOGLE_CLIENT_ID',raising=False)
    with pytest.raises(RuntimeError):create_app(tmp_path)

def test_legacy_claim(tmp_path,monkeypatch):
    monkeypatch.setenv('AUTH_MODE','receipt');monkeypatch.setenv('APP_USER','');monkeypatch.setenv('APP_PASSWORD','')
    with TestClient(create_app(tmp_path),base_url=ORIGIN) as c:
        original=upload(c).json();identifier=original['report']['id'];key=original['ownershipKey']
    for k,v in {'AUTH_MODE':'google','GOOGLE_CLIENT_ID':'test','GOOGLE_CLIENT_SECRET':'test','SESSION_SECRET':SECRET,'PUBLIC_BASE_URL':ORIGIN}.items():monkeypatch.setenv(k,v)
    with TestClient(create_app(tmp_path),base_url=ORIGIN) as c:
        with sqlite3.connect(tmp_path/'cyclewatch.sqlite3') as conn:
            for uid in ['a','b']:conn.execute('INSERT INTO users VALUES (?,?,?,?)',(uid,uid+'@example.com',uid,'now'))
        c.cookies.set('cyclewatch_session',cookie('a'),domain='localhost.local',path='/')
        assert c.post('/api/reports/'+identifier+'/claim',headers={'Origin':ORIGIN,'X-Report-Key':'wrong'}).status_code==403
        assert c.post('/api/reports/'+identifier+'/claim',headers={'Origin':ORIGIN,'X-Report-Key':key}).status_code==200
        c.cookies.clear();c.cookies.set('cyclewatch_session',cookie('b'),domain='localhost.local',path='/')
        assert c.post('/api/reports/'+identifier+'/claim',headers={'Origin':ORIGIN,'X-Report-Key':key}).status_code==403
        assert c.delete('/api/reports/'+identifier,headers={'Origin':ORIGIN,'X-Report-Key':key}).status_code==403
