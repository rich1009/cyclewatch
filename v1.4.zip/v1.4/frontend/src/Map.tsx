'use client';
import {useEffect,useRef} from 'react';
import type {Report} from './report';
import type {BikewayCollection} from './bikeways';

type Props={items:Report[];onSelect:(r:Report)=>void;onPick:(lat:number,lng:number)=>void;pick:boolean;center:[number,number]|null;bikeways:BikewayCollection|null;showUrban:boolean;showRiverside:boolean};
export default function Map({items,onSelect,onPick,pick,center,bikeways,showUrban,showRiverside}:Props){
 const el=useRef<HTMLDivElement>(null),map=useRef<any>(null),layer=useRef<any>(null),pickLayer=useRef<any>(null),routes=useRef<any>(null);
 const callbacks=useRef({onSelect,onPick,pick});callbacks.current={onSelect,onPick,pick};
 useEffect(()=>{
  let stopped=false;
  import('leaflet').then(L=>{
   if(stopped||!el.current)return;
   const m=L.map(el.current,{zoomControl:false}).setView([25.065,121.535],13);map.current=m;
   L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',maxZoom:19,referrerPolicy:'strict-origin-when-cross-origin'}).addTo(m);
   L.control.zoom({position:'bottomright'}).addTo(m);
   layer.current=L.layerGroup().addTo(m);pickLayer.current=L.layerGroup().addTo(m);
   m.createPane('bikeways');m.getPane('bikeways')!.style.zIndex='410';
   routes.current=L.layerGroup().addTo(m);
   m.on('click',(e:any)=>{if(callbacks.current.pick)callbacks.current.onPick(e.latlng.lat,e.latlng.lng)});
   window.dispatchEvent(new Event('cycle-map-ready'));
  });
  return()=>{stopped=true;map.current?.remove();map.current=null};
 },[]);
 useEffect(()=>{
  let active=true;
  const draw=()=>{if(!map.current||!layer.current)return;import('leaflet').then(L=>{
   if(!active||!map.current)return;
   layer.current.clearLayers();
   items.forEach(r=>{
    const color=r.severity==='危險'?'#df6746':r.severity==='注意'?'#c19724':'#258375';
    const marker=L.marker([r.lat,r.lng],{icon:L.divIcon({className:'issue-marker',html:`<span style="background:${color}">${r.category==='路面損壞'?'!':r.category==='障礙物'?'×':'•'}</span>`,iconSize:[34,40],iconAnchor:[17,38]})}).addTo(layer.current);
    const tip=document.createElement('span');tip.textContent=r.title;marker.bindTooltip(tip);marker.on('click',()=>callbacks.current.onSelect(r));
   });
  })};
  draw();window.addEventListener('cycle-map-ready',draw);
  return()=>{active=false;window.removeEventListener('cycle-map-ready',draw)};
 },[items]);
 useEffect(()=>{
  let active=true;
  const draw=()=>{if(!map.current||!routes.current)return;import('leaflet').then(L=>{
   if(!active||!map.current)return;
   routes.current.clearLayers();
   if(!bikeways)return;
   const visible=bikeways.features.filter(f=>f.properties.kind==='urban'?showUrban:showRiverside);
   L.geoJSON({type:'FeatureCollection',features:visible} as any,{
    pane:'bikeways',bubblingMouseEvents:false,
    style:f=>({color:f?.properties.kind==='urban'?'#1976be':'#8452ad',weight:4,opacity:.85}),
    onEachFeature:(feature:any,line:any)=>{
     const p=feature.properties;
     const box=document.createElement('div');
     const title=document.createElement('strong');title.textContent=p.name;box.appendChild(title);
     for(const text of [p.kind==='urban'?'市區自行車路網（含不同通行類型）':'河濱自行車道',p.start&&p.end?`${p.start} → ${p.end}`:'',`管養單位：${p.maintainer||'原資料未提供'}`,`資料提供：${p.publisher}`]){
      if(text){const row=document.createElement('div');row.textContent=text;box.appendChild(row)}
     }
     const link=document.createElement('a');link.textContent='查看官方資料來源';link.href=p.source_url;link.target='_blank';link.rel='noopener noreferrer';box.appendChild(link);
     line.bindPopup(box);
     line.on('click',(e:any)=>{if(callbacks.current.pick){line.closePopup();callbacks.current.onPick(e.latlng.lat,e.latlng.lng)}});
    }
   }).addTo(routes.current);
  })};
  draw();window.addEventListener('cycle-map-ready',draw);
  return()=>{active=false;window.removeEventListener('cycle-map-ready',draw)};
 },[bikeways,showUrban,showRiverside]);
 useEffect(()=>{
  let active=true;
  if(center&&map.current){map.current.setView(center,16);import('leaflet').then(L=>{
   if(active&&map.current&&pickLayer.current){pickLayer.current.clearLayers();if(pick)L.circleMarker(center,{radius:9,color:'#163f37',fillColor:'#b7ef70',fillOpacity:1}).addTo(pickLayer.current)}
  })}
  return()=>{active=false};
 },[center,pick]);
 return <div className={'map '+(pick?'picking':'')} ref={el} aria-label="臺北市官方自行車路網與問題地圖"/>;
}
