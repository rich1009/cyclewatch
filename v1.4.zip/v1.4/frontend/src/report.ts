import { z } from 'zod';
import type {BikewayMatch} from './bikeways';
export const reportInput = z.object({title:z.string().trim().min(2).max(80),description:z.string().trim().min(5).max(1500),category:z.enum(['路面損壞','障礙物','違規占用','照明問題','標線與設施','其他']),severity:z.enum(['一般','注意','危險']),lat:z.number().min(-90).max(90),lng:z.number().min(-180).max(180),accuracy:z.number().nonnegative().nullable(),locationSource:z.enum(['gps','photo_exif','manual'])});
export type Report = z.infer<typeof reportInput> & {id:string;status:string;createdAt:string;photoUrl:string|null;demo?:boolean;bikewayMatch?:BikewayMatch};
export function geojson(items:Report[]){return {type:'FeatureCollection',schema_version:'1.0',exported_at:new Date().toISOString(),coordinate_reference_system:'WGS84 / EPSG:4326',government_delivery_status:'not_submitted',features:items.map(({lat,lng,...properties})=>({type:'Feature',id:properties.id,geometry:{type:'Point',coordinates:[lng,lat]},properties}))};}
