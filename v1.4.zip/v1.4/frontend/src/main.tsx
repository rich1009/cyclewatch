import React from 'react';
import {createRoot} from 'react-dom/client';
import Page from './page';
import {initializeLiff} from './liff';
import './globals.css';
import 'leaflet/dist/leaflet.css';
const root=document.getElementById('root')!;
root.textContent='正在開啟騎路…';
initializeLiff().finally(()=>createRoot(root).render(<React.StrictMode><Page/></React.StrictMode>));
