import {z} from 'zod';
import {reportInput} from './report';
export const receiptSchema=z.object({
 report:reportInput.extend({id:z.string().uuid(),status:z.string().max(40),createdAt:z.string().max(60),updatedAt:z.string().max(60).optional(),photoUrl:z.string().max(500).nullable()}),
 ownershipKey:z.string().min(30).max(200).optional(),
 accountBound:z.boolean().optional(),
 photoDataUrl:z.string().max(8_000_000).regex(/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/).optional()
});
export type Receipt=z.infer<typeof receiptSchema>;
export const backupSchema=z.object({backup_type:z.literal('cyclewatch_private_backup'),version:z.literal('1.0'),server:z.string().url(),reports:z.array(receiptSchema).min(1).max(100)});
export const storageKey='cyclewatch-my-reports-v1';
export function readReceipts():Receipt[]{try{return z.array(receiptSchema).parse(JSON.parse(localStorage.getItem(storageKey)||'[]'))}catch{return []}}
export function downloadJson(data:unknown,filename:string){const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
