type Liff = typeof import('@line/liff').default;
let sdk:Liff|null=null;
let configuredId='';
let ready=false;
let errorText='';
export async function initializeLiff(){
 try{
  const response=await fetch('/api/auth/config',{signal:AbortSignal.timeout(8000)});
  if(!response.ok)return;
  const config=await response.json() as {liffId?:string};
  configuredId=config.liffId||'';
  if(!configuredId){ready=true;return}
  sdk=(await import('@line/liff')).default;
  const initialization=sdk.init({liffId:configuredId,withLoginOnExternalBrowser:false}).then(()=>{ready=true});
  let timer:ReturnType<typeof setTimeout>|undefined;
  try{await Promise.race([initialization,new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(Error('LIFF 初始化逾時，請重新開啟。')),15000)})])}finally{if(timer)clearTimeout(timer)}
 }catch{errorText='LINE 初始化未完成，請從 LIFF 連結重新開啟，或重新整理後重試。'}
}
export function canAdjustUrl(){return !configuredId||ready}
export function inLineBrowser(){return !!sdk?.isInClient()||/Line\//i.test(navigator.userAgent)}
export async function signInLine(link=false){
 if(!sdk||!ready)throw Error(errorText||'尚未設定或初始化 LIFF。');
 if(!sdk.isLoggedIn()){
  if(sdk.isInClient())throw Error('LINE 驗證尚未完成，請從 LIFF 連結重新開啟。');
  if(link)sessionStorage.setItem('cyclewatch-link-line','1');
  sdk.login({redirectUri:window.location.origin+'/'});
  return false;
 }
 const idToken=sdk.getIDToken();
 if(!idToken)throw Error('缺少 LINE ID token，請確認 LIFF 已啟用 openid scope。');
 const response=await fetch('/api/auth/liff/challenge',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({link})});
 const challenge=await response.json() as {challenge:string;error?:string};
 if(!response.ok)throw Error(challenge.error||'無法開始 LINE 驗證。');
 const result=await fetch('/api/auth/liff',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({idToken,challenge:challenge.challenge})});
 const body=await result.json() as {error?:string};
 if(!result.ok)throw Error(body.error||'LINE 登入失敗。');
 sessionStorage.removeItem('cyclewatch-link-line');
 return true;
}
export function pendingLineLink(){try{return sessionStorage.getItem('cyclewatch-link-line')==='1'}catch{return false}}
export function openGoogle(url:string){
 if(inLineBrowser()){
  if(!sdk)throw Error('請在 LINE 選單選「以其他瀏覽器開啟」，再使用 Google 登入。');
  sdk.openWindow({url:new URL(url,window.location.origin).href,external:true});
  return;
 }
 window.location.assign(url);
}
