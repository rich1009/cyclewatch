const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
function setup({logged=true,inClient=true}={}){
 const calls=[];
 const sdk={init:async config=>calls.push(['init',config]),isInClient:()=>inClient,isLoggedIn:()=>logged,getIDToken:()=> 'valid-id-token',login:config=>calls.push(['login',config]),openWindow:config=>calls.push(['openWindow',config])};
 global.window={location:{origin:'https://bike.example.com',assign:url=>calls.push(['assign',url])}};
 Object.defineProperty(global,'navigator',{value:{userAgent:inClient?'Line/15.0':'Chrome'},configurable:true});
 const storage=new Map();global.sessionStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
 global.fetch=async(url,options)=>{calls.push(['fetch',url,options]);return {ok:true,json:async()=>url==='/api/auth/config'?{liffId:'12345-test'}:url==='/api/auth/liff/challenge'?{challenge:'server-challenge'}:{authenticated:true}}};
 const out={};const source=ts.transpileModule(fs.readFileSync(path.resolve(__dirname,'../src/liff.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 new Function('require','exports',source)(name=>name==='@line/liff'?{default:sdk}:require(name),out);
 return {api:out,calls};
}
test('SDK 初始化前不允許改寫 LIFF URL',async()=>{const {api,calls}=setup();const init=api.initializeLiff();await init;assert.equal(api.canAdjustUrl(),true);assert.equal(calls.find(x=>x[0]==='init')[1].withLoginOnExternalBrowser,false)});
test('LINE 登入只送 ID token 與 session challenge，不送可偽造 profile',async()=>{const {api,calls}=setup();await api.initializeLiff();assert.equal(await api.signInLine(),true);const request=calls.find(x=>x[0]==='fetch'&&x[1]==='/api/auth/liff');assert.deepEqual(JSON.parse(request[2].body),{idToken:'valid-id-token',challenge:'server-challenge'})});
test('Google 在 LINE 內以外部瀏覽器開啟',async()=>{const {api,calls}=setup();await api.initializeLiff();api.openGoogle('/api/auth/google/login');assert.deepEqual(calls.find(x=>x[0]==='openWindow')[1],{url:'https://bike.example.com/api/auth/google/login',external:true});assert.equal(calls.some(x=>x[0]==='assign'),false)});
test('外部瀏覽器的 LINE 登入由 SDK login 導回 endpoint',async()=>{const {api,calls}=setup({logged:false,inClient:false});await api.initializeLiff();assert.equal(await api.signInLine(true),false);assert.equal(api.pendingLineLink(),true);assert.equal(calls.find(x=>x[0]==='login')[1].redirectUri,'https://bike.example.com/')});
test('LIFF 內驗證未完成時不錯用 SDK login',async()=>{const {api,calls}=setup({logged:false,inClient:true});await api.initializeLiff();await assert.rejects(()=>api.signInLine(),/驗證尚未完成/);assert.equal(calls.some(x=>x[0]==='login'),false)});
