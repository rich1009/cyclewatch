const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ts=require('typescript');
function loadTS(file){const out={};const source=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;new Function('require','exports',source)(name=>name.startsWith('.')?loadTS(path.resolve(path.dirname(file),name+'.ts')):require(name),out);return out;}
const {backupSchema,readReceipts,storageKey}=loadTS(path.resolve(__dirname,'../src/backup.ts'));
const receipt={report:{id:'64a17cf4-7f85-4ef8-9691-3bed393e61c7',title:'車道破損',description:'右側有明顯坑洞，請減速。',category:'路面損壞',severity:'危險',lat:25,lng:121,accuracy:null,locationSource:'manual',createdAt:'2026-10-19T00:00:00Z',status:'待確認',photoUrl:'/api/photos/test'},ownershipKey:'a'.repeat(43),photoDataUrl:'data:image/jpeg;base64,/9j/'};
const valid={backup_type:'cyclewatch_private_backup',version:'1.0',server:'https://bike.example.com',reports:[receipt]};
test('私人備份保留管理憑證、座標與照片',()=>{const parsed=backupSchema.parse(JSON.parse(JSON.stringify(valid)));assert.equal(parsed.reports[0].ownershipKey,receipt.ownershipKey);assert.equal(parsed.reports[0].report.lng,121);assert.equal(parsed.reports[0].photoDataUrl,receipt.photoDataUrl)});
test('公開 GeoJSON 不能冒充私人備份',()=>assert.equal(backupSchema.safeParse({type:'FeatureCollection',features:[]}).success,false));
test('拒絕短憑證、不合法座標及非照片內容',()=>{for(const r of [{...receipt,ownershipKey:'short'},{...receipt,report:{...receipt.report,lat:91}},{...receipt,photoDataUrl:'javascript:bad'}])assert.equal(backupSchema.safeParse({...valid,reports:[r]}).success,false)});
test('瀏覽器憑證可重讀，損壞或無權限時安全回復空列表',()=>{global.localStorage={getItem:key=>key===storageKey?JSON.stringify([receipt]):null};assert.equal(readReceipts()[0].ownershipKey,receipt.ownershipKey);global.localStorage={getItem:()=>'{bad json'};assert.deepEqual(readReceipts(),[]);global.localStorage={getItem:()=>{throw Error('Denied')}};assert.deepEqual(readReceipts(),[]);delete global.localStorage});
test('Google 帳號內容備份不包含可轉讓憑證',()=>{const parsed=backupSchema.parse({...valid,reports:[{report:receipt.report,accountBound:true,photoDataUrl:receipt.photoDataUrl}]});assert.equal(parsed.reports[0].ownershipKey,undefined);assert.equal(parsed.reports[0].accountBound,true)});
