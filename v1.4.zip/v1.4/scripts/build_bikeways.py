#!/usr/bin/env python3
"""Convert official Taipei CSV/KML/district SHP into versioned WGS84 GeoJSON.
Use --download to refresh from the fixed official sources; no map-tile scraping.
"""
from pathlib import Path
import argparse
import csv
from datetime import date,datetime
import hashlib
from io import BytesIO,StringIO
import json
import math
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from zoneinfo import ZoneInfo

import shapefile
from pyproj import CRS,Transformer
from shapely.geometry import LineString,MultiLineString,shape,mapping
from shapely.ops import unary_union
from shapely import make_valid,transform

ROOT=Path(__file__).resolve().parent.parent
SOURCES=[
 {'key':'urban','file':'taipei-urban.csv','name':'臺北市市區自行車道','publisher':'臺北市交通管制工程處','page':'https://data.taipei/dataset/detail?id=89202d05-0e3e-4781-a04f-45327bf12b30','url':'https://data.taipei/api/frontstage/tpeod/dataset/resource.download?rid=a69988de-6a49-4956-9220-40ebd7c42800','resource_updated':'2025-07-15','source_crs':'EPSG:3826 (市區 CSV 未附 CRS，依臺北市 TWD97 坐標政策與數值範圍採用；可透過 --urban-crs 更正)'},
 {'key':'riverside','file':'taipei-riverside.kml','name':'臺北市自行車道(河濱)','publisher':'臺北市政府工務局水利工程處','page':'https://data.gov.tw/dataset/143892','url':'https://data.taipei/api/dataset/4fefd1b3-58b9-4dab-af00-724c715b0c58/resource/0912d803-688f-493a-b682-27da729ed593/download','metadata_updated':'2026-07-21','source_crs':'WGS84 / EPSG:4326 (KML)'},
 {'key':'boundary','file':'taipei-districts.zip','name':'臺北市區界圖','publisher':'臺北市政府民政局','page':'https://data.gov.tw/dataset/121199','url':'https://data.taipei/api/dataset/1601ef3a-c253-4988-b047-943d9e786143/resource/d8b7eb29-136f-49fc-b14b-3489d3656122/download','source_crs':'TWD97 TM2 121 (以 ZIP 內 .prj 為準)'}]
LICENSE={'name':'政府資料開放授權條款－第1版','url':'https://data.gov.tw/license'}

def xy_parts(x,y,transformer):
    """# separates disconnected parts; never bridge these gaps."""
    xs,ys=x.split('#'),y.split('#')
    if len(xs)!=len(ys):raise ValueError('XY multipart count differs')
    parts=[]
    for xx,yy in zip(xs,ys):
        vx=[float(v.strip()) for v in xx.split(',') if v.strip()]
        vy=[float(v.strip()) for v in yy.split(',') if v.strip()]
        if len(vx)!=len(vy) or len(vx)<2:raise ValueError('XY point count differs or insufficient points')
        points=[]
        for xval,yval in zip(vx,vy):
            if not math.isfinite(xval+yval):raise ValueError('Non-finite source coordinates')
            lng,lat=transformer.transform(xval,yval)
            if not (120<lng<123 and 24<lat<26):raise ValueError('Unexpected Taipei coordinate range / CRS')
            points.append((lng,lat))
        parts.append(LineString(points))
    return parts

def only_lines(geometry):
    if geometry.is_empty:return []
    if geometry.geom_type=='LineString':return [geometry] if geometry.length>0 else []
    if geometry.geom_type in ('MultiLineString','GeometryCollection'):
        return [line for part in geometry.geoms for line in only_lines(part)]
    return []

def completed_on(value):
    v=value.strip()
    if not v.isdigit() or len(v)<5:raise ValueError('Unrecognized completion date')
    year=int(v[:-4]);year=year+1911 if year<1911 else year
    return date(year,int(v[-4:-2]),int(v[-2:]))

def build(raw_dir,output_dir,retrieved_on,urban_crs='EPSG:3826'):
    raw_dir,output_dir=Path(raw_dir),Path(output_dir)
    with zipfile.ZipFile(raw_dir/'taipei-districts.zip') as z:
        names={Path(n).suffix.lower():n for n in z.namelist() if Path(n).suffix.lower() in ('.shp','.shx','.dbf','.prj','.cpg')}
        source_crs=CRS.from_wkt(z.read(names['.prj']).decode('utf-8-sig'))
        encoding=z.read(names['.cpg']).decode().strip() if '.cpg' in names else 'utf-8'
        reader=shapefile.Reader(shp=BytesIO(z.read(names['.shp'])),shx=BytesIO(z.read(names['.shx'])),dbf=BytesIO(z.read(names['.dbf'])),encoding=encoding)
        boundary=unary_union([make_valid(shape(feature.__geo_interface__)) for feature in reader.iterShapes()])
    boundary=make_valid(transform(boundary,Transformer.from_crs(source_crs,4326,always_xy=True).transform,interleaved=False))
    if boundary.is_empty or not boundary.is_valid:raise ValueError('Invalid Taipei boundary')
    to_wgs=Transformer.from_crs(urban_crs,4326,always_xy=True)
    features=[];rejected=[]
    def add(identifier,parts,properties):
        original=MultiLineString(parts) if len(parts)>1 else parts[0]
        lines=only_lines(original.intersection(boundary))
        if not lines:
            rejected.append({'id':identifier,'reason':'outside_published_taipei_boundary'});return
        geom=MultiLineString(lines) if len(lines)>1 else lines[0]
        features.append({'type':'Feature','id':identifier,'geometry':mapping(geom),'properties':{'route_id':identifier,**properties}})
    rows=list(csv.DictReader(StringIO((raw_dir/'taipei-urban.csv').read_text(encoding='utf-8-sig'))))
    for i,row in enumerate(rows):
        identifier='urban:'+str(i+1)+':'+(row['路段序號'] or 'unnumbered')
        try:
            completion=completed_on(row['完工日期'])
            if completion>date.fromisoformat(retrieved_on):
                rejected.append({'id':identifier,'reason':'future_completion_date'});continue
            parts=xy_parts(row['路徑（X）'],row['路徑（Y）'],to_wgs)
            add(identifier,parts,{'kind':'urban','source_route_id':row['路段序號'],'name':row['路段名稱'],'start':row['路段起點描述'],'end':row['路段迄點描述'],'maintainer':row['管養單位'] or None,'publisher':SOURCES[0]['publisher'],'source_url':SOURCES[0]['page'],'type_code':row['自行車道類型'],'completed_on':completion.isoformat(),'published_width_m':row['自行車道寬度（M）'],'published_length_m':row['自行車道長度（M）']})
        except ValueError as exc:
            # Stop on malformed coordinate data instead of publishing a silently incomplete layer.
            raise ValueError(f'{identifier}: {exc}') from exc
    ns={'k':'http://www.opengis.net/kml/2.2'}
    marks=ET.parse(raw_dir/'taipei-riverside.kml').getroot().findall('.//k:Placemark',ns)
    for i,mark in enumerate(marks):
        name=mark.findtext('k:name',default='未命名河濱路段',namespaces=ns)
        parts=[]
        for line in mark.findall('.//k:LineString',ns):
            text=line.findtext('k:coordinates',default='',namespaces=ns)
            coords=[tuple(map(float,point.split(',')[:2])) for point in text.split()]
            if len(coords)<2:raise ValueError(f'Riverside {name}: insufficient points')
            parts.append(LineString(coords))
        if not parts:raise ValueError(f'Riverside {name}: no LineString')
        add('riverside:'+str(i+1),parts,{'kind':'riverside','name':name,'maintainer':None,'publisher':SOURCES[1]['publisher'],'source_url':SOURCES[1]['page']})
    ids=[x['id'] for x in features]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate route identifiers')
    metadata={'retrieved_on':retrieved_on,'license':LICENSE,'urban_source_crs_used':urban_crs,'display_crs':'WGS84 / EPSG:4326','distance_crs':'TWD97 / TM2 zone 121 (EPSG:3826)','boundary_clipped':True,'coverage_note':'官方公開圖資快照，可能未涵蓋最新新增、移除或調整之路段；圖線及緩衝比對不代表實際車道邊界或機關受理承諾。','input_urban_records':len(rows),'input_riverside_routes':len(marks),'feature_count':len(features),'counts':{k:sum(f['properties']['kind']==k for f in features) for k in ('urban','riverside')},'excluded':rejected,'sources':[{**s,'sha256':hashlib.sha256((raw_dir/s['file']).read_bytes()).hexdigest()} for s in SOURCES]}
    metadata['dataset_version']=hashlib.sha256(json.dumps(metadata,ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:16]
    output_dir.mkdir(parents=True,exist_ok=True)
    (output_dir/'taipei-bikeways.geojson').write_text(json.dumps({'type':'FeatureCollection','metadata':metadata,'features':features},ensure_ascii=False,separators=(',',':')))
    (output_dir/'taipei-boundary.geojson').write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','properties':{'name':'臺北市','source_url':SOURCES[2]['page']},'geometry':mapping(boundary)}]},ensure_ascii=False,separators=(',',':')))
    (output_dir/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
    return metadata

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-dir',type=Path,default=ROOT/'datasets'/'raw')
    parser.add_argument('--output-dir',type=Path,default=ROOT/'datasets')
    parser.add_argument('--retrieved-on',default=datetime.now(ZoneInfo('Asia/Taipei')).date().isoformat())
    parser.add_argument('--urban-crs',default='EPSG:3826')
    parser.add_argument('--download',action='store_true')
    args=parser.parse_args()
    if args.download:
        args.raw_dir.mkdir(parents=True,exist_ok=True)
        for source in SOURCES:
            with urllib.request.urlopen(source['url'],timeout=60) as response:
                data=response.read(20_000_001)
                if len(data)>20_000_000:raise ValueError('Source exceeds 20 MB')
                (args.raw_dir/source['file']).write_bytes(data)
    print(json.dumps(build(args.raw_dir,args.output_dir,args.retrieved_on,args.urban_crs),ensure_ascii=False,indent=2))
