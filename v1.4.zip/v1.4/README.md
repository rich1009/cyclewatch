# 騎路 CycleWatch — 自架伺服器測試版 v1.4

這是可獨立執行的完整程式，不需要 ChatGPT、Sites 或 Cloudflare 帳號。一般模式不需 API 金鑰；Google 登入模式需自行設定 OAuth Client。
前端 React + Leaflet，後端 FastAPI + SQLite，照片存放在伺服器磁碟。
下載包包含前端原始碼、已編譯網頁、後端原始碼、測試與 Docker 設定。

## 1. 最快啟動（Linux，已有 Python 即可）

需求：Python 3.11 以上；本版實測 Python 3.12。預先編譯的前端已包含在 `frontend/dist/`，直接測試不需要安裝 Node.js。

解壓後進入本專案：

```bash
unzip cyclewatch_selfhost_v1.0.zip
cd cyclewatch-selfhost
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
bash start.sh
```

在**伺服器本機**開啟：`http://127.0.0.1:8000`。
API 文件：`http://127.0.0.1:8000/docs`。
按 Ctrl+C 停止，之後重新執行 `source .venv/bin/activate` 與 `bash start.sh` 即可。

若要沿用你既有的 piggy 環境，可改用：

```bash
source /home/peter/piggy/bin/activate
cd /你的解壓位置/cyclewatch-selfhost
pip install -r requirements.txt
bash start.sh
```

專用 `.venv` 可避免影響既有研究程式的套件版本。

## 2. 從另一台電腦連線

方式 A：透過 SSH tunnel（保留只監聽 localhost 的預設）：

```bash
ssh -L 8000:127.0.0.1:8000 peter@你的伺服器IP
```

接著在自己的電腦開啟 `http://localhost:8000`。
注意：網頁 GPS 取得的是「開啟瀏覽器的裝置」的位置，不是伺服器的位置。

方式 B：同一個區域網路直接測試：

```bash
HOST=0.0.0.0 PORT=8000 bash start.sh
```

另一台裝置開啟 `http://伺服器區網IP:8000`；須確認防火牆允許該測試連線。
手機使用這種 HTTP IP 網址時，瀏覽器通常不允許即時 GPS；可先測試選擇照片與手動選點，或依第 5 節設定 HTTPS。
`0.0.0.0` 是監聽設定，不是瀏覽器應輸入的網址。

## 3. 使用 Docker

需求：Docker 與 Compose plugin。

```bash
cp .env.example .env
docker compose up -d --build
```

開啟 `http://127.0.0.1:8000`。Compose 預設只在本機開放連接埠。

```bash
docker compose logs -f
docker compose stop
docker compose start
```

資料保留在 `cyclewatch-data` named volume 中；`docker compose down` 不會刪除該 volume，`down -v` 則會刪除。
若需區網存取，在 `.env` 修改 `BIND_ADDRESS=0.0.0.0` 後執行 `docker compose up -d`。
此環境未實際執行 Docker 建置；已驗證的是 Python 後端及前端建置。

## 4. 可選的測試登入

本版預設不要求登入，適合本機測試。可啟用全站 HTTP Basic Auth，涵蓋網頁、API、照片與匯出。
兩個變數需一起設定；這是單一共用測試帳號，不是多使用者帳號管理。

直接執行：

```bash
export APP_USER='tester'
read -rsp '請輸入測試密碼: ' APP_PASSWORD
export APP_PASSWORD
bash start.sh
```

Docker 則在 `.env` 填入 `APP_USER` 與 `APP_PASSWORD`，再執行 `docker compose up -d`。
登入啟用時請透過 HTTPS 或 SSH tunnel 存取；正式公開服務還需要個別帳號、權限及審核流程。

## 5. 手機拍照與 HTTPS

- 手機瀏覽器可選擇拍照／上傳照片。
- 照片有 EXIF GPS 時會嘗試讀取；轉傳、截圖或部分手機瀏覽器可能移除定位資訊。
- 「使用 GPS」需要裝置授權，且通常需 HTTPS（localhost 是開發例外）。
- 照片 GPS、目前手機 GPS、手動選點是不同來源，送出前請確認。
- GPS 的 accuracy 是瀏覽器提供的誤差估計；照片 GPS 未提供精度時不會捏造數值。
- 地圖與照片能回報任意經緯度，初始畫面在台北，並未強制限制縣市。

有網域時可用 Caddy 反向代理。將 `Caddyfile.example` 的網域換成你的網域，DNS 指向主機，對外開放 80/443，後端維持 127.0.0.1:8000。
Caddy 設定範例已附，實際安裝方式依你的作業系統而定。
如使用 Docker，Caddy 可在宿主機執行並代理到宿主機的 8000 埠。

若使用 `/api/export`，可設定 `PUBLIC_BASE_URL=https://你的網域`，讓附件連結使用對外網址。
網頁上的匯出按鈕會使用當前瀏覽器網址產生完整照片連結。
啟用登入時，照片網址仍需要登入，不能視為政府系統可匿名下載的附件網址。

## 6. 功能與測試流程

1. 首頁預設讀取真實回報，初次資料庫為空；勾選「示範」可看示範標記。
2. 點「回報車道問題」，拍照或選圖。
3. 確認位置：照片 GPS、使用手機 GPS、地圖選點或手動輸入。
4. 填入標題、分類、嚴重程度及說明，勾選分享同意後送出。
5. 回報儲存為「待確認」，其他連到同一台伺服器的使用者重新整理即可查看。
6. 點回報卡片可查看照片與資訊，支援分類、關鍵字與危險程度篩選。
7. 「匯出 .JSON」匯出目前篩選結果；若勾選示範資料，示範資料也會匯出並帶 `demo: true`。
8. 關閉伺服器再重啟，確認原回報與照片仍存在。

新回報不會自動標為政府已受理。本版尚未有政府端派工或公開修改處理狀態的功能；持有私人憑證者可修改回報內容。

## 7. 資料格式與 API

| 路徑 | 方法 | 用途 |
| --- | --- | --- |
| `/api/health` | GET | 健康狀態 |
| `/api/reports` | GET | 全部真實回報 |
| `/api/reports` | POST | multipart：`report` JSON 字串 + `photo` 檔案 |
| `/api/photos/{id}` | GET | 回報照片 |
| `/api/export` | GET | 匯出全部真實回報為 GeoJSON（不含示範資料） |
| `/docs` | GET | OpenAPI 互動文件 |

JSON 匯出採 GeoJSON FeatureCollection，WGS84 / EPSG:4326。
Point.coordinates 的順序是 **[經度, 緯度]**，不是反過來。

`properties` 包含 id、title、description、category、severity、status、createdAt、locationSource、accuracy、photoUrl。
分類：路面損壞、障礙物、違規占用、照明問題、標線與設施、其他。
影響程度：一般、注意、危險。定位來源：gps、photo_exif、manual。
時間儲存為 UTC，介面以裝置時區顯示。
頂層 `government_delivery_status` 為 `not_submitted`，不代表任何機關已接案。

## 8. 檔案與備份

```text
backend/app.py             後端 API、照片處理、資料庫
frontend/src/page.tsx       回報與列表介面
frontend/src/Map.tsx        Leaflet GIS 地圖
frontend/src/report.ts     前端欄位驗證及 GeoJSON
frontend/src/globals.css    樣式
frontend/dist/             已編譯可直接使用的網頁
requirements.txt           後端主要套件版本
requirements-lock.txt      測試環境完整 pip freeze（含測試套件）
tests/test_api.py           API 整合測試
Dockerfile / compose.yaml  Docker 部署
start.sh                   Linux 啟動腳本
```

直接執行時，資料在 `data/cyclewatch.sqlite3` 與 `data/uploads/`。
SQLite 可能另有 WAL/SHM 檔案。最簡單的完整備份方式是先停止程式，再複製整個 `data/` 目錄。
不要只備份 SQLite 而漏掉照片。`DATA_DIR` 可指定絕對儲存路徑，該目錄需可寫入。
解壓包不包含任何真實民眾回報資料。

## 9. 修改前端

需要 Node.js 22.13+ 或 24；本版以 Node.js 24 測試。

```bash
cd frontend
npm ci
npm run dev
```

開發頁面預設 `http://localhost:5173`，API 代理到 127.0.0.1:8000，需另外啟動後端。
完成修改後：

```bash
npm run build
cd ..
bash start.sh
```

每次修改前端都要重新 build，然後讓瀏覽器重新整理；後端靜態檔案掛載是在啟動時檢查。

## 10. 執行測試

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

涵蓋新增／讀取回報、照片處理與移除 EXIF、重啟保留、GeoJSON 座標順序、無效欄位、上傳大小、跨來源限制、可選登入、靜態網頁與錯誤路徑。
前端亦經 TypeScript 檢查與 Vite production build。手機相機／GPS 權限及不同瀏覽器需在你的實際裝置上驗證。

## 11. 政府介接與目前界線

目前有 JSON 匯出，**尚未連接任何政府系統**。
需先指定縣市及權責單位，取得其 API、授權及附件格式，再加入送件、機關案件編號、失敗重試、派工與修復狀態同步。
只產生 JSON 檔不等於政府可以直接匯入；照片的存取授權也需共同處理。

這是自架測試版，並未提供管理者審核、重複案件合併、使用者管理、持久化限流、大量資料分頁、個資遮蔽或正式派工。
照片會重新編碼、最大邊長縮至 1600px，伺服器再次驗證影像並移除 EXIF；回報座標仍是刻意分享的資料，並不會因此匿名化。
單張上傳影像上限 4 MB，整個請求上限 6 MB；超大影像像素量也會拒絕。
OpenStreetMap 底圖仍需網路；v1.4 已加入官方公開自行車路網，但未提供離線底圖、離線送件或原生 App 封裝。
底圖瓦片服務與元件有各自的授權及使用條款，正式大量服務時需安排合適的底圖供應與流量方案。

## 地圖顯示 Access blocked（修正 v1.0.1）

已修正舊版 `Referrer-Policy: same-origin` 導致跨站底圖請求無法提供 Referer 的設定，改為 `strict-origin-when-cross-origin`，並改用 OSM 正式瓦片網址及明示影像 referrerPolicy。
依據：https://operations.osmfoundation.org/policies/tiles/
此修正符合來源資訊要求，但不保證解除因 IP、流量、瀏覽器隱私擴充套件或其他原因造成的封鎖。

原地更新時，先停止服務，再用更新包覆蓋程式與 `frontend/dist/`，保留原來 `data/`、`.venv/`、`.env`，然後重新啟動並按 Ctrl+F5。
Docker 使用者需執行 `docker compose up -d --build`。
若畫面仍快取舊封鎖圖片，可先用一般重新整理，必要時清除該網站快取；不要連續強制重新整理或批量下載底圖。

## v1.1：使用者備份、修改與刪除

更新後建立的新回報會在「我的回報」保存管理憑證，無需另外註冊帳號。

- 送出後點右上「我的回報」→「下載備份」。私人備份 JSON 包含回報內容、JPEG 照片（base64）及該筆回報的管理憑證。
- 「修改」可更新標題、分類、嚴重程度、說明、座標，並可選擇更換照片；不更換時保留原照片。
- 「刪除」需再次確認，會刪除伺服器紀錄及照片。已下載的私人備份仍保留在使用者裝置，伺服器無法替使用者刪除該副本。
- 換裝置、清除瀏覽器儲存或換網址／埠號後，使用「匯入私人備份」恢復管理權。回報須仍存在於同一套伺服器資料庫。匯入不會重新建立已刪除的回報，也不會覆寫伺服器現有內容；匯入後需明確執行「修改」。
- 私人備份包含修改／刪除權限，取得備份的人就能管理該筆回報，請勿公開分享。一般地圖 GeoJSON 匯出不含這些憑證。
- 瀏覽器只自動保存管理憑證與回報文字，不自動永久保存照片；完整照片副本需按「下載備份」。瀏覽器拒絕儲存時，憑證只留在本次頁面，請立即下載備份。
- 新增 API：`GET /api/reports/{id}/manage`、`PATCH /api/reports/{id}`、`DELETE /api/reports/{id}`。每個請求需帶 `X-Report-Key`。修改使用 multipart 的 report JSON（與新增相同欄位），photo 可省略。若同時啟用全站 Basic Auth，也需通過全站登入。
- 伺服器只儲存隨機憑證的 SHA-256 雜湊，不會把憑證放進公開列表或 GeoJSON。

### 舊版升級

先停止服務，備份整個 `data/`，再以更新包覆蓋程式與 `frontend/dist/`，保留 `data/`、`.venv/` 及 `.env`。
重新執行 `bash start.sh` 會自動增補 SQLite 欄位，不清除原回報。Docker 使用者執行 `docker compose up -d --build`，保留原 volume。
**舊版既有回報未產生管理憑證，仍可查看，但不提供訪客自行認領或刪除。**
如憑證與私人備份均遺失，本版沒有使用者端帳號找回流程。

前端私人備份測試：`cd frontend && npm run test:backup`。
v1.1 本次驗證：20 項後端測試、4 項備份資料測試，及 TypeScript / production build 通過；尚未以實體手機測試下載與匯入操作。

## v1.2：Google 帳號登入

Google 模式中，公開地圖與照片可瀏覽；新增回報及管理回報需登入。回報以 Google 的固定 subject ID 綁定帳號，不以可變動的信箱文字判定所有權。同一個 Google 帳號跨裝置登入即可管理，公開列表／GeoJSON 不包含 Google ID、信箱或姓名。

### 你目前透過 SSH 的本機測試設定

1. 前往 https://console.cloud.google.com/ ，建立／選取你自己的專案。
2. 在 Google Auth Platform 設定應用程式名稱、聯絡資訊及 Audience；測試模式時加入自己的 Google 帳號作為測試使用者。
3. 建立 OAuth Client，類型選「Web application」。
4. 在 Authorized redirect URIs 加入**完全相同**的網址：`http://localhost:18000/api/auth/google/callback`。
5. 複製產生的 Client ID 與 Client Secret，填在伺服器專案目錄的 `.env`，不需交給任何人：

```dotenv
AUTH_MODE=google
APP_USER=
APP_PASSWORD=
GOOGLE_CLIENT_ID=你的ClientID.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=你的ClientSecret
SESSION_SECRET=你自行產生的至少32字元隨機字串
PUBLIC_BASE_URL=http://localhost:18000
```

產生 SESSION_SECRET：

```bash
python3 -c "import secrets; print(secrets.token_urlsafe(48))"
```

安裝新版套件並重新啟動：

```bash
source .venv/bin/activate
pip install -r requirements.txt
bash start.sh
```

Windows 的 SSH tunnel 維持原本可用設定，將本機 18000 轉送到伺服器 8000。Windows 瀏覽器必須從 `http://localhost:18000` 開啟；按右上「我的回報」→「使用 Google 帳號登入」。Google 登入完成會返回 localhost，再經 SSH tunnel 到伺服器。
這是電腦的本機測試方式，不能把 localhost 網址傳給別人的手機使用。

本版後端會讀取專案根目錄 `.env`，已設定的系統環境變數優先。`AUTH_MODE=google` 缺少必要設定時會直接拒絕啟動，不會悄悄變成免登入。
`.env` 不要放進公開程式庫，亦不會包含在下載包；SESSION_SECRET 更換後，既有登入 cookie 失效，但回報資料保留。

### 手機與公開網址

設定穩定 HTTPS 網域（例如 `https://bike.example.com`），將 PUBLIC_BASE_URL 改成該 origin，並在 Google Console 增加 `https://bike.example.com/api/auth/google/callback`。
也可使用你已有的 HTTPS ngrok 網址作短期測試，但 Google Console 的 callback 必須與當前網址完全一致；目前 SSH 使用的 TCP 位址不能直接拿來當網頁 callback。
不得使用外部純 HTTP IP 作正式 Google 模式網址。localhost HTTP 僅限本機測試。
本版本使用伺服器端 redirect flow，不需要額外載入瀏覽器 Google SDK。

### 權限與舊回報

- 新增回報綁定目前登入者，另一個 Google 帳號無法修改／刪除，即使知道案件 ID 也不行。
- 舊私人備份可於登入後匯入並確認綁定；也可按「綁定此瀏覽器保存的舊回報」。伺服器驗證原管理憑證，成功後原憑證即失效，改由該 Google 帳號管理。
- 已綁定其他帳號的案件不能靠私人憑證轉移。完全沒有原管理憑證的舊回報不能由訪客認領。
- Google 模式下載的內容／照片備份不包含可轉讓的管理權，管理仍需原 Google 帳號；匯入內容備份不會重建已刪除案件。
- 登出只登出此網站，不會登出整個 Google 帳號。
- 本版不提供整個帳號刪除、所有裝置登出或帳號轉移；回報可逐筆刪除。

### 登入實作與驗證範圍

使用 Authlib 的 OpenID Connect authorization code flow，處理 state、nonce、PKCE 與 ID token 驗證。只請求 `openid email profile`，不請求 Gmail、Drive 或其他 Google 資料。
Google access token / refresh token 不持久保存。登入 cookie 使用簽章、HttpOnly、SameSite=Lax；HTTPS 網址加上 Secure，期限為七天。SQLite 保存必要的帳號資料與回報所有權。
請維持 HTTPS 及 SESSION_SECRET 保密；簽章 cookie 在到期前有效，登出會清除目前瀏覽器 cookie。
本次可自動驗證登入設定、session 驗證、使用者所有權隔離及模擬回呼；尚未使用你的 Google Cloud OAuth Client 做真實端到端登入。

官方文件：
- https://developers.google.com/identity/protocols/oauth2/web-server
- https://developers.google.com/identity/openid-connect/openid-connect

Google 登入版 v1.2 驗證：27 項後端測試、5 項前端備份資料測試通過；TypeScript 與前端 build 通過。Google 真實登入仍需填入你自己的 OAuth Client 後實測。


## v1.3：LIFF ＋ LINE / Google 雙登入

同一套網頁可作為 LIFF App，在 LINE 內拍照、定位、回報、查看地圖、修改／刪除、下載／匯入私人備份。也能在一般瀏覽器使用。這不是聊天機器人，不需要 Messaging API webhook，也不需要 LINE 官方帳號才能完成回報。

### 先準備公開 HTTPS 網址

LIFF 必須有手機可連到的 HTTPS 網址，不能以 SSH 的 localhost 當成正式 LIFF endpoint。
保留伺服器 `bash start.sh`（127.0.0.1:8000），可先在同一台伺服器另開終端機，以你已安裝且登入的 ngrok 執行：

```bash
ngrok http 8000
```

ngrok 會顯示 HTTPS 網址。這和先前用來連 SSH 的 `tcp://...` 入口不同；請使用 HTTP tunnel 顯示的 HTTPS 網址。
以下用 `https://bike.example.com` 作示例，請全部替換成你的實際 HTTPS 網址。
ngrok 網址若變動，PUBLIC_BASE_URL、Google callback、LINE LIFF endpoint 都要一致更新。正式對外建議使用固定網址。

### LINE Developers 設定

1. 前往 https://developers.line.biz/console/ ，建立／選取 Provider，並建立 **LINE Login channel**（Web app）。
2. 在該 Channel 的 LIFF 分頁新增 LIFF App：
   - Size：Full。
   - Endpoint URL：`https://bike.example.com/`。
   - Scope：`openid`、`profile`。本版不需要 email scope，也不需要申請 LINE 信箱存取。
   - 如需要，可啟用使用者自行開啟應用程式所需的相關選項；實際選單依 Console 為準。
3. 取得該 LINE Login Channel ID 與新增 LIFF 的 LIFF ID。
4. Channel 尚在開發階段時，僅限具有該 Channel 對應權限的測試帳號使用；完成實測後依 Console 流程開放正式使用。
5. 本版 LINE 登入使用 LIFF SDK 的 `liff.init()` / `liff.login()`，伺服器用 LINE ID-token verify API 驗證，不使用獨立 LINE OAuth callback route；不需要填寫不存在的 `/api/auth/line/callback`，也不需要 LINE Channel Secret。
6. 提供給民眾的 LINE 入口為 Console 顯示的 LIFF URL，通常是 `https://liff.line.me/你的LIFF_ID`。

### Google 設定

沿用既有 Web application OAuth Client，新增 Authorized redirect URI：

```text
https://bike.example.com/api/auth/google/callback
```

本版 Google 登入透過伺服器 redirect，不需使用前端 Google SDK。不要把 Client Secret 填進 LIFF endpoint 或前端原始碼。

### 伺服器 .env

```dotenv
AUTH_MODE=dual
PUBLIC_BASE_URL=https://bike.example.com
SESSION_SECRET=請填入你自行產生的至少32字元隨機字串
SESSION_DAYS=7
GOOGLE_CLIENT_ID=你的GoogleClientID.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=你的GoogleClientSecret
LINE_CHANNEL_ID=你的LINELoginChannelID
LIFF_ID=你的LIFF_ID
APP_USER=
APP_PASSWORD=
```

`SESSION_SECRET` 可用先前章節的 Python secrets 指令產生。不要將上述中文示例直接當正式金鑰。
支援 AUTH_MODE：`receipt`（原始私人憑證）、`google`、`line`（只提供 LIFF LINE）、`dual`（兩者）。預設仍是 receipt，更新不會強制改動既有環境。

更新後請安裝後端新版套件並重啟：

```bash
source .venv/bin/activate
pip install -r requirements.txt
bash start.sh
```

前端 dist 已編譯，直接測試不需 Node.js。修改前端時才需 `cd frontend && npm ci && npm run build`。
Docker 使用者同樣填寫 `.env`，再 `docker compose up -d --build`。

### 兩種登入的行為

- LINE：點「我的回報」→「使用 LINE 帳號登入」，在 LIFF 內沿用 LINE 登入。一般瀏覽器會依 LIFF SDK 流程跳到 LINE 登入再回到本網頁。
- Google：一般瀏覽器直接登入；在 LINE / LIFF 內按 Google 時會透過 SDK 開啟外部瀏覽器，避免 Google 的嵌入式 user-agent 限制。完成後會在外部瀏覽器繼續操作，不會偷偷把外部瀏覽器登入憑證傳回 LIFF。
- LINE WebView 和 Safari／Chrome 的 Cookie 並非同一份；在其中一處登入不代表另一處也已登入。
- 開啟 LIFF 的 SDK 初始化會依 LINE 平台行為取得必要授權；網站不會因為 SDK 已登入就自行切換你正在使用的 Google 帳號。必須明確選擇 LINE 登入。
- 保持登入由網站自己的 HttpOnly Cookie 管理，預設 7 天，可透過 SESSION_DAYS 設為 1–90 天。關閉網頁一般仍能保持，但 LINE／作業系統清理 WebView Cookie、瀏覽器限制或無痕模式可能導致需要重新登入。
- 登出網站會清除網站登入，不代表退出 LINE App 或整個 Google 帳號；下次仍可自行點按 LINE 登入。

### 明確綁定兩個登入身分

兩種身分**不會依姓名或信箱自動合併**。

若要共用同一批回報：在一般外部瀏覽器先登入已使用的身分，於「我的回報」按「綁定 LINE 帳號」或「綁定 Google 帳號」，確認後完成另一方的驗證。
例如：先以 LINE 登入 Safari 網頁 → 綁定 Google → 之後用這個 LINE 或 Google 身分登入，都能管理相同回報。
若從 LIFF 內按綁定 Google，介面會要求先在外部瀏覽器以 LINE 登入後綁定，避免跨瀏覽器 Cookie 不共用造成誤綁。

**若兩個登入身分已各自建立獨立帳號，系統會拒絕自動合併。** 本版未提供既有雙帳號的資料合併、換綁或解除綁定流程，不會移動別人的回報。
舊版 Google 使用者與回報透過資料庫 migration 保留，舊 Google Cookie 在相同 SESSION_SECRET 下可繼續使用。
私人憑證模式的回報仍可透過先前的備份匯入方式綁定到目前帳號。

### 安全與測試界線

- SDK 在使用者明確點按時提供 ID token；後端將原始 token 送到固定的 LINE verify endpoint，並驗證預期 Channel ID、issuer、期限與 subject。不相信前端傳來的 user ID／姓名。
- 登入與綁定採同源檢查及 session challenge；Google 綁定另以 state 綁定原帳號。
- LINE ID token、Google access token 均不持久儲存、不放進備份、公開 GeoJSON 或網址。
- LIFF SDK 初始化完成前，不改寫 LIFF 的 query parameters。Google OAuth 頁面不在 LINE WebView 中載入。
- 公開地圖與照片仍可查看，個人登入資料只顯示於自己的管理頁。
- 自動測試涵蓋 LINE token 驗證失敗、憑證來源／期限、帳號隔離、明確綁定、拒絕已存在帳號自動合併及舊資料遷移。尚未用你的真實 LINE Channel、Google OAuth Client 或實體手機驗證端到端流程。

官方文件：
- https://developers.line.biz/en/docs/liff/using-user-profile/
- https://developers.line.biz/en/docs/liff/developing-liff-apps/
- https://developers.line.biz/en/reference/line-login/#verify-id-token
- https://developers.google.com/identity/protocols/oauth2/policies

v1.3 本次自動驗證：42 項後端測試、5 項私人備份資料測試、5 項 LIFF 前端流程測試，及 TypeScript／production build 通過。前端 LIFF 流程使用 SDK 測試替身；真實 LINE／Google 驗證需使用你自己的 Channel 與 Client，在實體手機上測試。
前端 LIFF 測試：`cd frontend && npm run test:liff`。


## v1.4：臺北市官方自行車路網圖層與範圍比對

### 已包含的官方快照

圖資已隨程式包附上，不必申請圖資 API 金鑰或在啟動時下載；地圖底圖仍使用連網 OSM。

| 圖層 | 官方資料來源 | 本包筆數 | 處理方式 |
| --- | --- | --- | --- |
| 市區路網（藍色） | 臺北市交通管制工程處「臺北市市區自行車道」 | 478 筆路段紀錄 | CSV 路徑 X/Y 轉成 WGS84 GeoJSON，保留類型代碼及原始管養單位 |
| 河濱路線（紫色） | 臺北市政府工務局水利工程處「臺北市自行車道(河濱)」 | 7 條路線 | KML 轉換，保留原來不連續的線段 |
| 臺北市界（比對用） | 臺北市政府民政局「臺北市區界圖」 | 12 區合併市界 | 讀取 .prj 的 TWD97 座標，合併區界 |

本包下載整理日為 **2026-10-21（臺北時間）**，不是原資料的測量日期。
市區來源頁記載檔案更新 2025-07-15；河濱來源的詮釋資料更新日期是 2026-07-21，不能把詮釋資料日期當成所有路段現況更新日期。
所有路線均依官方市界裁切，避免原河濱圖資跨越新北市部分被當成臺北市內範圍；靠近市界仍需現場／機關確認。

來源：
- 市區：https://data.taipei/dataset/detail?id=89202d05-0e3e-4781-a04f-45327bf12b30
- 河濱：https://data.gov.tw/dataset/143892
- 市界：https://data.gov.tw/dataset/121199
- 政府資料開放授權條款：https://data.gov.tw/license

原始檔、SHA-256、來源網址及處理資訊保存在 `datasets/raw/` 與 `datasets/metadata.json`。
官方路網包含不同自行車通行類型，不能一律視為專用道；本版不把原始類型代碼自行翻譯成未經確認的通行規則。

### 手機與地圖操作

- 地圖左上圖層控制可個別開關「市區路網」與「河濱路線」。
- 點擊圖線可看路段名稱、起迄、原資料記載的管養單位、資料提供單位與官方來源連結。
- 河濱原資料未提供逐段管養單位時，顯示未提供，不把「資料提供機關」直接當成案件承辦機關。
- 回報設定位置後自動顯示距最近圖線的距離與比對狀態。
- 「僅顯示市內路網附近回報」只篩出符合系統條件的回報；再按原本的匯出按鈕，即匯出目前篩選結果。
- 未匹配圖資仍可回報，避免因圖資遺漏、道路新增或 GPS 誤差而拒絕民眾回報。示範資料不會混入已比對案件。

### 比對規則

使用 EPSG:3826 公尺座標系統與 STRtree 尋找最近路網圖線，不直接把經緯度角度當公尺。
預設圖線距離 **20 公尺**，可於 `.env` 設定 `BIKEWAY_BUFFER_METERS`（1–100）；變更後重啟程式。這是中心線附近的系統容許距離，不是官方車道面範圍或法定車道寬度。

- `matched`：位於官方市界內、距圖線不超過門檻，且未觸發下列誤差／市界疑慮。
- `unmatched`：市界內，但沒有鄰近圖線。不能據此斷言該處沒有自行車道。
- `outside_taipei`：回報座標在此版市界外。
- `needs_review`：GPS 誤差大於 50 公尺、GPS 估計誤差可能跨過比對門檻／市界，或座標在市界約 3 公尺內。請手動確認位置。
- `unavailable`：圖資未載入；不是「範圍外」，也不會誤標為符合。

**「政府優先處理」仍需由你與權責機關確認規則。本版只提供路網比對與優先整理候選，不代表政府已受理、核定管轄或承諾處理順序。**
市區 CSV 沒有隨檔提供 CRS；本版依臺北市公開 TWD97 坐標政策與 X/Y 數值範圍採 EPSG:3826。河濱依 KML 的 WGS84，市界依 ZIP 的 .prj。若取得市區資料提供單位不同 CRS 說明，應使用下方 --urban-crs 重建，不應靠擴大門檻補償坐標錯誤。

### JSON 與 API

每筆真實回報新增只讀 `bikewayMatch`，包含：
`status`、`inside_taipei`、`within_buffer`、`distance_m`、`buffer_m`、`nearest_route`、`position_accuracy_m`、`priority_candidate`、`government_priority_confirmed`、`dataset_version`、`retrieved_on`。
`priority_candidate` 是系統整理候選；`government_priority_confirmed` 目前一律 false。
前端不能自行指定比對結果，伺服器會依座標計算；修改位置時會重新計算。既有回報亦可直接比對，不需重建資料庫。
比對反映目前載入的圖資版本，不是當初送件時的不可變快照；更新圖資後結果可能改變，JSON 會記錄版本方便追溯。

新增 GET API：
- `/api/bikeways`：官方圖線 GeoJSON 與來源 metadata。
- `/api/bikeways/boundary`：官方市界 GeoJSON。
- `/api/bikeways/match?lat=25.033&lng=121.565&accuracy=8`：單點比對，accuracy 可省略。

`/api/export` 仍匯出全部真實回報；網頁「匯出 .JSON」按鈕才是匯出當前篩選結果。政府送件狀態仍是 not_submitted。

### 更新／重新轉換圖資

原始資料已包含，可不連網重建：

```bash
python scripts/build_bikeways.py --retrieved-on 2026-10-21
```

需要從官方來源更新時：

```bash
python scripts/build_bikeways.py --download
```

執行後檢查輸出的 feature counts、excluded、來源日期與轉換範圍，再重啟伺服器。下載日期只代表本次取得時間，資料來源可能尚未更新。
若資料提供單位確認市區 CSV CRS 不同，可指定 `--urban-crs EPSG:xxxx`。
腳本保留 CSV 中以 # 分隔的不同線段，不會以直線跨越空隙；重複或空白的來源路段編號以本包唯一 ID 區分，並保留原始編號。
來源資料若有無法解析的坐標／完工日期，腳本停止並指出路段，不會靜默發布不完整結果。

### 自架升級

先停止程式，備份原有 `data/`，再覆蓋程式與 **datasets/**、**frontend/dist/**；保留 `.env`、`.venv/` 及原有 `data/`。

```bash
source .venv/bin/activate
pip install -r requirements.txt
bash start.sh
```

瀏覽器重新整理後可見圖層。Dockerfile 已加入 datasets，使用 `docker compose up -d --build` 即會包含圖資。
若圖層顯示未載入，請確認專案根目錄有 `datasets/taipei-bikeways.geojson` 及 `datasets/taipei-boundary.geojson`；也可透過 BIKEWAY_DATA_DIR 指定完整目錄。

v1.4 本次自動驗證：50 項後端測試、5 項私人備份測試、5 項 LIFF 前端流程測試，以及 TypeScript／production build 通過。GIS 測試涵蓋公尺距離、市界裁切、GPS 誤差、位置修改後重算及匯出結果；尚未進行實體手機圖層操作測試。
